import Vue from "vue";
import Vuex from "vuex";

import posts from "./modules/posts.js";
import authentication from "./modules/authentication.js";
import settings from "./modules/settings.js";

Vue.use(Vuex);

const store = new Vuex.Store({
  modules: {
    posts,
    authentication,
    settings
  }
});

export default store;
