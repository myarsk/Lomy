import "../../plugins/axios";
import _ from "lodash";
import qs from "qs";

const state = {
	posts: [],
	pendingPosts: [],
	reportedPosts: [],
	post: {},
	comments: [],
	countries: [],
	types: [],
	tagPosts: [],
	tags: [],
	ads: [],
};
const mutations = {
	fetchPosts(state, posts) {
		state.posts = [...state.posts, ...posts];
	},
	emptyPosts(state) {
		state.posts = [];
	},
	fetchPendingPosts(state, pendingPosts) {
		state.pendingPosts = [...state.pendingPosts, ...pendingPosts];
	},
	emptyPendingPosts(state) {
		state.pendingPosts = [];
	},
	fetchReportedPosts(state, reportedPosts) {
		state.reportedPosts = [...state.reportedPosts, ...reportedPosts];
	},
	emptyReportedPosts(state) {
		state.reportedPosts = [];
	},
	fetchTagPosts(state, tagPosts) {
		state.tagPosts = [...state.tagPosts, ...tagPosts];
	},
	emptyTagPosts(state) {
		state.tagPosts = [];
	},
	fetchPost(state, post) {
		state.post = post;
	},
	fetchComments(state, comments) {
		state.comments = comments;
	},
	addComment(state, comment) {
		state.comments = [...state.comments, comment];
	},
	deleteComment(state, id) {
		state.comments = state.comments.filter((comment) => comment.id !== id);
	},
	deletePost(state, postId) {
		state.posts = state.posts.filter((post) => post.id !== postId);
	},
	deletePendingPost(state, postId) {
		state.pendingPosts = state.pendingPosts.filter(
			(post) => post.id !== postId,
		);
	},
	deleteReportedPost(state, postId) {
		state.reportedPosts = state.reportedPosts.filter(
			(post) => post.id !== postId,
		);
	},
	likePost(state, { postId, postObject }) {
		const find = (post) => post.id == postId;
		let index = state.posts.findIndex(find);
		let index2 = state.tagPosts.findIndex(find);
		if (state.tagPosts[index2]) {
			state.tagPosts[index2].likes = postObject.likes;
			state.tagPosts[index2].dislikes = postObject.dislikes;
			state.tagPosts[index2].liked = true;
			state.tagPosts[index2].disliked = false;
		}
		if (state.posts[index]) {
			state.posts[index].likes = postObject.likes;
			state.posts[index].dislikes = postObject.dislikes;
			state.posts[index].liked = true;
			state.posts[index].disliked = false;
		}
		state.post.likes = postObject.likes;
		state.post.dislikes = postObject.dislikes;
		state.post.liked = true;
		state.post.disliked = false;
	},
	dislikePost(state, { postId, postObject }) {
		const find = (post) => post.id == postId;
		let index = state.posts.findIndex(find);
		let index2 = state.tagPosts.findIndex(find);
		if (state.tagPosts[index2]) {
			state.tagPosts[index2].likes = postObject.likes;
			state.tagPosts[index2].dislikes = postObject.dislikes;
			state.tagPosts[index2].liked = false;
			state.tagPosts[index2].disliked = true;
		}
		if (state.posts[index]) {
			state.posts[index].likes = postObject.likes;
			state.posts[index].dislikes = postObject.dislikes;
			state.posts[index].liked = false;
			state.posts[index].disliked = true;
		}
		state.post.likes = postObject.likes;
		state.post.dislikes = postObject.dislikes;
		state.post.liked = false;
		state.post.disliked = true;
	},
	fetchAds(state, data) {
		state.ads = data;
	},
	fetchCountries(state, data) {
		state.countries = data;
	},
	fetchTypes(state, data) {
		state.types = data;
	},
	fetchTags(state, data) {
		state.tags = data;
	},
};
const actions = {
	async all_posts({ commit }, data) {
		commit("emptyTagPosts");
		return await new Promise((resolve, reject) => {
			axios
				.post("/post", qs.stringify(data))
				.then((res) => {
					if (data.page == 0) commit("emptyPosts");
					commit("fetchPosts", res.data);
					resolve(res);
				})
				.catch((err) => {
					if (data.page == 0) commit("emptyPosts");
					reject(err);
				});
		});
	},
	async pending_posts({ commit }, data) {
		if (data.page == 0) commit("emptyPendingPosts");
		return await new Promise((resolve, reject) => {
			axios
				.post("/post/pending", qs.stringify(data))
				.then((res) => {
					res.data["content"]
						? commit("fetchPendingPosts", res.data["content"])
						: null;
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async reported_posts({ commit }, data) {
		if (data.page == 0) commit("emptyReportedPosts");
		return await new Promise((resolve, reject) => {
			axios
				.post("/post/reported", qs.stringify(data))
				.then((res) => {
					res.data["content"]
						? commit("fetchReportedPosts", res.data["content"])
						: null;
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async get_post({ commit }, postId) {
		return await new Promise((resolve, reject) => {
			axios
				.get("/post/" + postId)
				.then((res) => {
					commit("fetchPost", res.data);
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async get_all_comments({ commit }, postId) {
		return await new Promise((resolve, reject) => {
			axios
				.post(
					"/post/getAllPostComments",
					qs.stringify({
						postId,
					}),
				)
				.then((res) => {
					commit("fetchComments", res.data);
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async submit_comment({ commit }, data) {
		return await new Promise((resolve, reject) => {
			axios
				.post("/post/addComment/", qs.stringify(data))
				.then((res) => {
					commit("addComment", res.data);
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async delete_post({ commit }, postId) {
		return await new Promise((resolve, reject) => {
			axios
				.delete("/post/delete/", {
					headers: {
						"Content-Type": "application/x-www-form-urlencoded",
					},
					data: qs.stringify({
						postId,
					}),
				})
				.then((res) => {
					commit("deletePost", postId);
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async like_post({ commit }, postId) {
		return await new Promise((resolve, reject) => {
			axios
				.post(
					"post/likePost/",
					qs.stringify({
						postId,
					}),
				)
				.then((res) => {
					commit("likePost", { postId, postObject: res.data });
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async dislike_post({ commit }, postId) {
		return await new Promise((resolve, reject) => {
			axios
				.post(
					"post/dislikePost/",
					qs.stringify({
						postId,
					}),
				)
				.then((res) => {
					commit("dislikePost", { postId, postObject: res.data });
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async filterby_tag({ commit }, data) {
		commit("emptyPosts");
		if (data.page == 0) commit("emptyTagPosts");
		return await new Promise((resolve, reject) => {
			axios
				.post("post/filterByTag", qs.stringify(data))
				.then((res) => {
					commit("fetchTagPosts", res.data);
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async new_post({ commit }, data) {
		return await new Promise((resolve, reject) => {
			axios({
				method: "post",
				url: "post/create/",
				data: data,
				headers: {
					"Content-Type": "multipart/form-data",
				},
			})
				.then((res) => {
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async accept_post({ commit }, data) {
		return await new Promise((resolve, reject) => {
			axios
				.post("post/acceptPost/", qs.stringify(data))
				.then((res) => {
					commit("deletePendingPost", data.postId);
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async reject_post({ commit }, data) {
		return await new Promise((resolve, reject) => {
			axios
				.post("post/rejectPost/", qs.stringify(data))
				.then((res) => {
					commit("deletePendingPost", data.postId);
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async reportPost({ commit }, data) {
		return await new Promise((resolve, reject) => {
			axios
				.post("post/reportPost/", qs.stringify(data))
				.then((res) => {
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async verifyTag({ commit }, data) {
		return await new Promise((resolve, reject) => {
			axios
				.post("tag/verifyTag/", qs.stringify(data))
				.then((res) => {
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async unverifyTag({ commit }, data) {
		return await new Promise((resolve, reject) => {
			axios
				.post("tag/removeVerification/", qs.stringify(data))
				.then((res) => {
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async createAd({ commit }, data) {
		return await new Promise((resolve, reject) => {
			axios({
				method: "post",
				url: "ad/create/",
				data: qs.stringify(data),
				// headers: {
				// 	"Content-Type": "multipart/form-data",
				// },
			})
			.then((res) => {
				resolve(res);
			})
			.catch((err) => {
				reject(err);
			});
		});
	},
	async deleteComment({ commit }, data) {
		return await new Promise((resolve, reject) => {
			axios
				.post("post/deleteComment/", qs.stringify(data))
				.then((res) => {
					commit("deleteComment", data.commentId);
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async getAllAds({ commit }) {
		return await new Promise((resolve, reject) => {
			axios
				.post("ad/")
				.then((res) => {
					commit("fetchAds", res.data);
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async fetch_countries({ commit }) {
		return await new Promise((resolve, reject) => {
			axios
				.post("country/getCountries")
				.then((res) => {
					commit("fetchCountries", res.data);
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async fetch_types({ commit }) {
		return await new Promise((resolve, reject) => {
			axios
				.post("Type/getTypes")
				.then((res) => {
					commit("fetchTypes", res.data);
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
	async fetch_tags({ commit }) {
		return await new Promise((resolve, reject) => {
			axios
				.post("tag/getAll")
				.then((res) => {
					commit("fetchTags", res.data);
					resolve(res);
				})
				.catch((err) => {
					reject(err);
				});
		});
	},
};
const getters = {
	allPosts(state) {
		return state.posts;
	},
	allPendingPosts(state) {
		return state.pendingPosts;
	},
	allReportedPosts(state) {
		return state.reportedPosts;
	},
	allTagPosts(state) {
		return state.tagPosts;
	},
	post(state) {
		return state.post;
	},
	allComments(state) {
		return state.comments;
	},
	allCountries(state) {
		return state.countries;
	},
	allTypes(state) {
		return state.types;
	},
	allTags(state) {
		return state.tags;
	},
	getAd(state) {
		return _.sample(state.ads);
	},
};

export default {
	state,
	getters,
	actions,
	mutations,
};
