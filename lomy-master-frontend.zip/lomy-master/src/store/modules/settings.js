import '../../plugins/axios';
import qs from "qs";

const state = {
};
const mutations = {
};
const actions = {
    async addCountry({ commit }, data) {
        return await new Promise((resolve, reject) => {
            axios.post(
                "/country/",
                qs.stringify(data),
            )
            .then((res) => {
                resolve(res)
            })
            .catch((err) => {
                reject(err)
            });
        })
    },
    async createType({ commit }, data) {
        return await new Promise((resolve, reject) => {
            axios.post(
                "/Type/",
                qs.stringify(data),
            )
            .then((res) => {
                resolve(res)
            })
            .catch((err) => {
                reject(err)
            });
        })
    },
};
const getters = {
};

export default {
    state,
    getters,
    actions,
    mutations
}