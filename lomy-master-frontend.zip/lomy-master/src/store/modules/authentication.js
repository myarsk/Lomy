import '../../plugins/axios';
import qs from "qs";

const state = {
    token: localStorage.getItem("token")? localStorage.getItem("token") : null,
    userId: localStorage.getItem("userId")? localStorage.getItem("userId") : null,
    role: localStorage.getItem("role")? localStorage.getItem("role") : null,
    email: localStorage.getItem("email")? localStorage.getItem("email") : null,
};
const mutations = {
	auth_success(state, data) {
		localStorage.setItem("token", data[0]);
		axios.defaults.headers.common["Authorization"] = "Bearer " + data[0];
		data[1].forEach((element) => {
			localStorage.setItem("role", element.roleName);
			state.role = element.roleName;
		});
		state.token = data[0];
	},
	auth_error(state, data) {
		localStorage.removeItem("token");
		localStorage.removeItem("role");
		localStorage.removeItem("email");
		axios.defaults.headers.common["Authorization"] = null;
		state.token = null;
		state.role = null;
	},
	logout(state) {
		localStorage.removeItem("token");
		localStorage.removeItem("role");
		localStorage.removeItem("email");
		axios.defaults.headers.common["Authorization"] = null;
		state.token = null;
		state.role = null;
	},
	verify(state, data) {
		localStorage.setItem("email", data.email);
		state.email = data.email;
	},
};
const actions = {
    async login({ commit }, data) {
        return await new Promise((resolve, reject) => {
            axios.post(
                "/user/login",
                qs.stringify(data),
            )
            .then((res) => {
                commit('auth_success', res.data)
                resolve(res)
            })
            .catch((err) => {
                // if (
				// 	err.response.status == 403 &&
				// 	err.response.data == "please activate this user"
                // ) {
                //     commit("verify", data.email);
				// }
                reject(err)
            });
        })
    },
    async register({ commit }, data) {
        return await new Promise((resolve, reject) => {
            axios.post(
                "/user",
                qs.stringify(data),
            )
            .then((res) => {
                commit("verify", data);
				resolve(res);
            })
            .catch((err) => {
                reject(err)
            });
        })
    },
    async verify({ commit }, data) {
        return await new Promise((resolve, reject) => {
            axios.post(
                "/user/activate/",
                qs.stringify(data),
            )
            .then((res) => {
                resolve(res)
            })
            .catch((err) => {
                reject(err)
            });
        })
    },
    async logout({ commit }) {
        return await new Promise((resolve, reject) => {
            commit('logout')
            resolve()
        })
    },
};
const getters = {
    isLoggedIn: (state) => !!state.token,
    role: (state) => state.role,
    verifyEmail: (state) => state.email,
};

export default {
    state,
    getters,
    actions,
    mutations
}