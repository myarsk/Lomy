import Vue from "vue";
import VueRouter from "vue-router";
import store from "./store/index.js";

// import Welcome from "./pages/auth/Welcome";
// import Signin from "./pages/auth/Signin";
// import Signup from "./pages/auth/Signup";

// import Home from "./pages/Home";
// import About from "./pages/About";
// import Contact from "./pages/Contact";
// import Policy from "./pages/Policy";
// import NewPost from "./pages/NewPost";
// import Start from "./pages/Start";
// import Posts from "./pages/Posts";

Vue.use(VueRouter);

const router = new VueRouter({
  mode: "history",
  routes: [
    {
      path: "*",
      component: () => import('./pages/404'),
      meta: {
        auth: false
      }
    },
    {
      path: "/welcome",
      component: () => import('./pages/auth/Welcome'),
      meta: {
        auth: false
      }
    },
    {
      path: "/signin",
      component: () => import('./pages/auth/Signin'),
      meta: {
        auth: false
      }
    },
    {
      path: "/signup",
      component: () => import('./pages/auth/Signup'),
      meta: {
        auth: false
      }
    },
    {
      path: "/verify",
      component: () => import('./pages/auth/Verify'),
      meta: {
        auth: false
      }
    },
    {
      path: "/",
      component: () => import('./pages/Home'),
      meta: {
        auth: true
      }
    },
    {
      path: "/about",
      component: () => import('./pages/About'),
      meta: {
        auth: true
      }
    },
    {
      path: "/contact",
      component: () => import('./pages/Contact'),
      meta: {
        auth: true
      }
    },
    {
      path: "/policy",
      component: () => import('./pages/Policy'),
      meta: {
        auth: true
      }
    },
    {
      path: "/start",
      component: () => import('./pages/Start'),
      meta: {
        auth: true
      }
    },
    {
      path: '/posts/pending_posts',
      component: () => import('./pages/PendingPosts'),
      meta: {
        auth: true
      }
    },
    {
      path: '/posts/reported_posts',
      component: () => import('./pages/ReportedPosts'),
      meta: {
        auth: true
      }
    },
    {
      path: "/posts/:type",
      component: () => import('./pages/Posts'),
      meta: {
        auth: true
      }
    },
    {
      path: "/posts/:type/new_post",
      component: () => import('./pages/NewPost'),
      meta: {
        auth: true
      }
    },
    {
      path: '/posts/:type/:postId',
      component: () => import('./pages/Post'),
      meta: {
        auth: true
      }
    },
    {
      path: '/tag/:type/:tag',
      component: () => import('./pages/Tag'),
      meta: {
        auth: true
      }
    },
    {
      path: '/settings',
      component: () => import('./pages/Settings'),
      meta: {
        auth: true
      }
    },
  ]
});

router.beforeEach((to, from, next) => {
  if (to.matched.some(record => record.meta.auth)) {
    // this route requires auth, check if logged in
    // if not, redirect to login page.
    if (!store.getters.isLoggedIn) {
      next({
        path: '/signin',
        query: { redirect: to.fullPath }
      })
    } else {
      next()
    }
  } else {
    next()
  }
})

export default router;
