<template>
    <div class="about">
        <v-container fluid>
            <v-row class="content-section section1">
                <v-col
                    cols="12"
                    md="6"
                    :data-aos="$vuetify.rtl? 'fade-left': 'fade-right'"
                    class="content-wrap"
                >
                    <img src="/img/Image.svg" class="background-svg" />
                    <span class="themed-circle"></span>
                    <div class="content-text">
                        <h1>{{ $vuetify.lang.t("$vuetify.what_is_opinions") }}</h1>
                        <p>{{ $vuetify.lang.t("$vuetify.opinions_desc") }}</p>
                    </div>
                </v-col>
                <v-col cols="12" md="6" data-aos="fade-up" class="img-wrap">
                    <img src="/img/criticism.svg" />
                </v-col>
            </v-row>
            <v-row class="content-section section2">
                <v-col
                    cols="12"
                    md="6"
                    :data-aos="$vuetify.rtl? 'fade-left': 'fade-right'"
                    order="1"
                    order-md="2"
                    class="content-wrap"
                >
                    <img src="/img/Image.svg" class="background-svg" />
                    <span class="themed-circle"></span>
                    <div class="content-text">
                        <h1>{{ $vuetify.lang.t("$vuetify.what_is_lomyo") }}</h1>
                        <p>{{ $vuetify.lang.t("$vuetify.lomyo_desc") }}</p>
                    </div>
                </v-col>
                <v-col
                    cols="12"
                    md="6"
                    data-aos="fade-up"
                    order="2"
                    order-md="1"
                    class="img-wrap"
                >
                    <img src="/img/experience.svg" />
                </v-col>
            </v-row>
        </v-container>
    </div>
</template>

<script>
export default {
    name: "About",
    metaInfo: {
        title: 'About us',
        meta: [
            {name: 'description', content: 'this is the about us'}
        ]
    },
};
</script>
