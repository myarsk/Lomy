<template>
	<v-container class="new-post-container" fluid>
		<v-row no-gutters justify="space-around">
			<v-col cols="12" class="d-flex align-center">
				<h1
					:data-aos="$vuetify.rtl ? 'fade-left' : 'fade-right'"
					class="font-weight-regular"
				>
					{{ $vuetify.lang.t("$vuetify.settings") }}
				</h1>
			</v-col>
			<v-form
				@submit.prevent="addCountry"
				data-aos="fade-up"
				class="flex-column form-container"
			>
				<h3 class="col-12 px-0 mb-2">
					{{ $vuetify.lang.t("$vuetify.add_country") }}
				</h3>
				<v-text-field
					class="mb-4"
					v-model="country"
					:label="$vuetify.lang.t('$vuetify.country')"
					solo
					hide-details
					dense
				></v-text-field>
				<v-text-field
					class="mb-4"
					v-model="language"
					:label="$vuetify.lang.t('$vuetify.language')"
					solo
					hide-details
					dense
				></v-text-field>
				<v-btn color="accent" type="submit">{{
					$vuetify.lang.t("$vuetify.add_country")
				}}</v-btn>
			</v-form>
			<!-- <v-form
                @submit.prevent="createTag"
                data-aos="fade-up"
                class="flex-column form-container"
            >
                <h3 class="col-12 px-0 mb-2">{{ $vuetify.lang.t('$vuetify.create_tag') }}</h3>
                <v-text-field
                class="mb-4"
                v-model="tag"
                solo
                hide-details
                dense
                ></v-text-field>
                <v-btn color="accent" type="submit">{{ $vuetify.lang.t('$vuetify.create_tag') }}</v-btn>
            </v-form> -->
			<v-form
				@submit.prevent="createType"
				data-aos="fade-up"
				class="flex-column form-container"
			>
				<h3 class="col-12 px-0 mb-2">
					{{ $vuetify.lang.t("$vuetify.create_type") }}
				</h3>
				<v-text-field
					class="mb-4"
					v-model="type"
					:label="$vuetify.lang.t('$vuetify.type')"
					solo
					hide-details
					dense
				></v-text-field>
				<v-btn color="accent" type="submit">{{
					$vuetify.lang.t("$vuetify.create_type")
				}}</v-btn>
			</v-form>
			<v-form
				@submit.prevent="verifyTag"
				data-aos="fade-up"
				class="flex-column form-container"
			>
				<h3 class="col-12 px-0 mb-2">
					{{ $vuetify.lang.t("$vuetify.verify_tag") }}
				</h3>
				<v-text-field
					class="mb-4"
					v-model="username"
					:label="$vuetify.lang.t('$vuetify.username')"
					solo
					hide-details
					dense
				></v-text-field>
				<v-autocomplete
					class="mb-4"
					:items="allTags"
					item-text="tag"
					item-value="id"
					v-model="tag"
					:label="$vuetify.lang.t('$vuetify.tag')"
					solo
					hide-details
					dense
				></v-autocomplete>
				<v-btn color="error" @click="unverifyTag">{{
					$vuetify.lang.t("$vuetify.unverify")
				}}</v-btn>
				<v-btn color="accent" @click="verifyTag">{{
					$vuetify.lang.t("$vuetify.verify")
				}}</v-btn>
			</v-form>
			<v-form
				@submit.prevent="createAd"
				data-aos="fade-up"
				class="flex-column form-container"
			>
				<h3 class="col-12 px-0 mb-2">
					{{ $vuetify.lang.t("$vuetify.create_ad") }}
				</h3>
				<v-text-field
					class="mb-4"
					v-model="ad"
					:label="$vuetify.lang.t('$vuetify.ad')"
					solo
					hide-details
					dense
				></v-text-field>
				<!-- <v-file-input
					dense
					small-chips
					solo
                    truncate-length="10"
					v-model="adImg"
				></v-file-input> -->
				<v-btn color="accent" type="submit">{{
					$vuetify.lang.t("$vuetify.create")
				}}</v-btn>
			</v-form>
		</v-row>
	</v-container>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	name: "Settings",
	metaInfo: {
		title: "Settings",
		meta: [{ name: "description", content: "this is the settings page" }],
	},
	props: ["overlay", "toggleOverlay"],
	data() {
		return {
			country: null,
			language: null,
			type: null,
			tag: null,
			ad: null,
			adImg: null,
			username: null,
		};
	},
	created() {
		this.$store.dispatch("fetch_tags");
	},
	computed: {
		...mapGetters(["allTags"]),
	},
	methods: {
		addCountry() {
			this.toggleOverlay(true);
			this.$store
				.dispatch("addCountry", {
					country: this.country,
					language: this.language,
				})
				.then(() => {
					this.toggleOverlay(false);
					this.country = null;
					this.language = null;
				})
				.catch(() => {
					this.toggleOverlay(false);
				});
		},
		createType() {
			this.toggleOverlay(true);
			this.$store
				.dispatch("createType", {
					type: this.type,
				})
				.then(() => {
					this.toggleOverlay(false);
					this.type = null;
				})
				.catch(() => {
					this.toggleOverlay(false);
				});
		},
		verifyTag() {
			this.toggleOverlay(true);
			this.$store
				.dispatch("verifyTag", {
					tagId: this.tag,
					userName: this.username,
				})
				.then(() => {
					this.toggleOverlay(false);
					this.tag = null;
					this.username = null;
				})
				.catch(() => {
					this.toggleOverlay(false);
				});
		},
		unverifyTag() {
			this.toggleOverlay(true);
			this.$store
				.dispatch("unverifyTag", {
					tagId: this.tag,
					userName: this.username,
				})
				.then(() => {
					this.toggleOverlay(false);
					this.tag = null;
					this.username = null;
				})
				.catch(() => {
					this.toggleOverlay(false);
				});
		},
		createAd() {
			this.toggleOverlay(true);
			this.$store
				.dispatch("createAd", {
					ad: this.ad,
					// image: this.adImg,
				})
				.then(() => {
					this.toggleOverlay(false);
					this.ad = null;
					// this.adImg = null;
				})
				.catch(() => {
					this.toggleOverlay(false);
				});
		},
	},
};
</script>

<style></style>
