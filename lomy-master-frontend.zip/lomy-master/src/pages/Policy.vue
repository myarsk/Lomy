<template>
	<div>
		<v-container fluid>
			<v-row class="content-section section1">
				<v-col cols="12" data-aos="fade-right" class="content-wrap">
					<!-- <span class="themed-circle"></span> -->
					<div class="content-text">
						<h1>{{ $vuetify.lang.t("$vuetify.lomy_polices") }}</h1>
						<ul class="normal-list">
							<!-- <transition-group
                                name="fade"
                                mode="out-in"
                            > -->
							<li
								v-for="(policy, index) in polices"
								:key="policy.id"
								data-aos="fade-right"
								:data-aos-delay="index * 100"
							>
								{{ policy.value }}
							</li>
							<!-- </transition-group> -->
						</ul>
					</div>
				</v-col>
				<v-col cols="12">
					<router-link to="/">
						<v-img
							class="mt-auto ad"
							src="https://www.adspeed.com/placeholder-728x90-Test.gif"
						/>
					</router-link>
				</v-col>
			</v-row>
		</v-container>
	</div>
</template>

<script>
import { mapGetters } from "vuex";

export default {
	name: "Policy",
	metaInfo: {
		title: "Policy",
		meta: [{ name: "description", content: "this is the policy page" }],
	},
	created() {
		this.$store.dispatch("getAllAds");
	},
	computed: {
		...mapGetters(["getAd"]),
		polices() {
			// console.log(this.$vuetify.lang.t())
			// return this.$vuetify.lang.t(`$vuetify.lomy_polices_list.0`)
			return [
				{
					id: 1,
					value: this.$vuetify.lang.t("$vuetify.lomy_polices"),
				},
				{
					id: 2,
					value: this.$vuetify.lang.t("$vuetify.lomy_polices"),
				},
				{
					id: 3,
					value: this.$vuetify.lang.t("$vuetify.lomy_polices"),
				},
				{
					id: 4,
					value: this.$vuetify.lang.t("$vuetify.lomy_polices"),
				},
				{
					id: 5,
					value: this.$vuetify.lang.t("$vuetify.lomy_polices"),
				},
			];
		},
	},
};
</script>
