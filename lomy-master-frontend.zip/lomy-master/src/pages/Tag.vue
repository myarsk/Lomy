<template>
	<v-container class="posts-container">
		<v-btn
			@click.prevent="
				hasHistory() ? $router.go(-1) : $router.push('/posts')
			"
			color="accent"
			class="mb-4"
		>
			&laquo; {{ $vuetify.lang.t("$vuetify.back") }}
		</v-btn>
		<v-row no-gutters>
			<v-col v-if="allTags[0]" cols="12" class="post-card-container">
				<v-card class="post-card-wrap">
					<v-card-title class="card-title">
						<h2 class="mb-0">
							#{{ allTags[0].tag.tag }}
							<v-icon color="blue darken-1"
								>mdi-check-decagram</v-icon
							>
						</h2>
						<v-spacer></v-spacer>
						({{
							$formatDecimal(allTags[0].tag.numberOfRaters == 0
								? 0
								: allTags[0].tag.rating /
								allTags[0].tag.numberOfRaters)
								  
						}})
						<v-tooltip bottom color="accent">
							<template v-slot:activator="{ on, attrs }">
								<div v-bind="attrs" v-on="on">
									<v-rating
										empty-icon="mdi-star-outline"
										full-icon="mdi-star"
										half-icon="mdi-star-half-full"
										hover
										readonly
										half-increments
										length="5"
										size="25"
										:value="parseFloat (
											$formatDecimal(allTags[0].tag.numberOfRaters == 0
												? 0
												: allTags[0].tag.rating /
												allTags[0].tag.numberOfRaters)
										)"
										color="accent"
									></v-rating>
								</div>
							</template>
							<span>{{
								$formatDecimal(allTags[0].tag.numberOfRaters == 0
									? 0
									: allTags[0].tag.rating /
									allTags[0].tag.numberOfRaters)
							}}</span>
						</v-tooltip>
					</v-card-title>
				</v-card>
			</v-col>
			<v-col
				cols="12"
				v-for="(post, index) in allTags"
				:key="index"
				class="post-card-container"
			>
				<v-card
					:to="'/posts/' + $route.params.type + '/' + post.id"
					:class="'post-card-wrap ' + postBodySpecial(post.postText)"
				>
					<v-card-title class="card-title">
						<v-avatar size="25">
							<img alt="user" src="/img/logo-circled.svg" />
						</v-avatar>
						<p>
							{{
								role == "ROLE_AUTHOR"
									? post.visible == "INVISIBLE" ||
									  $route.params.type == "lomyo"
										? $vuetify.lang.t("$vuetify.anonymous")
										: post.user.userName
									: post.user.userName
							}}
						</p>
						<v-spacer></v-spacer>
						<v-tooltip bottom color="accent">
							<template v-slot:activator="{ on, attrs }">
								<div v-bind="attrs" v-on="on">
									<v-rating
										empty-icon="mdi-star-outline"
										full-icon="mdi-star"
										half-icon="mdi-star-half-full"
										hover
										readonly
										half-increments
										length="5"
										size="25"
										:value="post.postRating"
										color="accent"
									></v-rating>
								</div>
							</template>
							<span>{{ post.postRating }}</span>
						</v-tooltip>
						<!-- <v-menu v-if="post.author" offset-x :left="!$vuetify.rtl">
                            <template v-slot:activator="{ on, attrs }">
                                <v-btn icon v-bind="attrs" v-on.stop="on">
                                    <v-icon>mdi-dots-vertical</v-icon>
                                </v-btn>
                            </template>
                            <v-list class="py-0" dense>
                                <v-list-item
                                    @click.stop="
                                        delete_dialog = true;
                                        delete_post = post.id;
                                    "
                                    dense
                                >
                                    <v-list-item-title
                                        ><v-icon size="18">mdi-delete</v-icon
                                        >Delete</v-list-item-title
                                    >
                                </v-list-item>
                            </v-list>
                        </v-menu> -->
					</v-card-title>
					<v-card-text>
						<router-link
							:to="
								'/tag/' +
									$route.params.type +
									'/' +
									post.tag.tag
							"
						>
							<v-tooltip top>
								<template v-slot:activator="{ on, attrs }">
									<h2 v-bind="attrs" v-on="on">
										#{{ post.tag.tag }}
										<v-icon
											v-if="post.verified == 'VERIFIED'"
											color="blue darken-1"
											>mdi-check-decagram</v-icon
										>
									</h2>
								</template>
								<span>Click for tag info</span>
							</v-tooltip>
						</router-link>
						<p>
							{{ postBodyParser(post.postText) }}
						</p>
						<div class="post-images">
							<img
								v-for="(img, index) in post.media"
								:key="index"
								:src="'/img/uploads/' + img.media"
								class="elevation-2"
							/>
						</div>
					</v-card-text>
					<v-card-actions>
						<v-spacer></v-spacer>
						<ShareNetwork
							class="social-icon"
							network="facebook"
							:url="currentUrl + '/' + post.id"
							:title="postBodyParser(post.postText)"
							:description="postBodyParser(post.postText)"
							:hashtags="post.tag.tag"
						>
							<v-btn icon>
								<img src="/img/facebook.svg" alt="" />
							</v-btn>
						</ShareNetwork>
						<ShareNetwork
							class="social-icon"
							network="twitter"
							:url="currentUrl + '/' + post.id"
							:title="postBodyParser(post.postText)"
							:description="postBodyParser(post.postText)"
							:hashtags="post.tag.tag"
						>
							<v-btn icon>
								<img src="/img/twitter.svg" alt="" />
							</v-btn>
						</ShareNetwork>
					</v-card-actions>
				</v-card>
				<v-form
					@submit.prevent="submitComment(post.id, index)"
					class="post-card-form pb-4"
				>
					<v-text-field
						v-if="comments[index]"
						:label="$vuetify.lang.t('$vuetify.comment')"
						v-model="comments[index].comment"
						solo
						hide-details
						dense
					>
						<template v-slot:append>
							<v-btn
								min-width="18px"
								icon
								type="submit"
								color="primary"
								fab
								x-small
							>
								<v-icon>mdi-send</v-icon>
							</v-btn>
						</template>
					</v-text-field>
					<div class="flex-wrap">
						<v-btn
							@click="likePost(post.id)"
							:class="post.liked ? ' ' : ' opacity'"
							color="accent"
						>
							{{ $vuetify.lang.t("$vuetify.good") }}
							<span class="number-span">{{
								post.likes | formatNumber
							}}</span>
						</v-btn>
						<v-btn
							@click="dislikePost(post.id)"
							:class="post.disliked ? '' : 'opacity'"
							color="error"
						>
							{{ $vuetify.lang.t("$vuetify.bad") }}
							<span class="number-span">{{
								post.dislikes | formatNumber
							}}</span>
						</v-btn>
					</div>
				</v-form>
			</v-col>
		</v-row>
		<scroll-loader :loader-method="getTags" :loader-disable="disable">
		</scroll-loader>
	</v-container>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	name: "Post",
	data() {
		return {
			page: 0,
			empty: true,
			disable: false,
			comments: [],
		};
	},
	created() {},
	computed: {
		...mapGetters(["allTagPosts", "role"]),
		allTags() {
			this.comments = [];
			for (let index = 0; index < this.allTagPosts.length; index++) {
				const element = this.allTagPosts[index];
				this.comments = [
					...this.comments,
					{
						comment: null,
					},
				];
			}
			return this.allTagPosts;
		},
		currentUrl() {
			return window.location;
		},
	},
	methods: {
		hasHistory() {
			return window.history.length > 2;
		},
		likePost(i) {
			this.$store.dispatch("like_post", i);
		},
		dislikePost(i) {
			this.$store.dispatch("dislike_post", i);
		},
		getTags() {
			this.$store
				.dispatch("filterby_tag", {
					tag: this.$route.params.tag,
					isExperience:
						this.$route.params.type == "opinions" ? true : false,
					page: this.page++,
				})
				.then((res) => {
					this.empty = false;
				})
				.catch((err) => {
					this.page == 1 ? (this.empty = true) : null;
					this.disable = true;
				});
		},
		submitComment(postId, index) {
			if (this.comments[index]) {
				this.$store
					.dispatch("submit_comment", {
						postId: postId,
						comment: this.comments[index].comment,
						visible: this.anonymous ? "INVISIBLE" : "VISIBLE",
					})
					.then((res) => {
						this.comments[index].comment = null;
					})
					.catch((err) => {});
			}
		},
		postBodyParser(str) {
			if (str.includes("/***")) {
				str = str.replace("/***", "");
				return str;
			} else if (str.includes("/*/**")) {
				str = str.replace("/*/**", "");
				return str;
			} else {
				return str;
			}
		},
		postBodySpecial(str) {
			if (str.includes("/***")) {
				return "yellow-border";
			} else if (str.includes("/*/**")) {
				return "red-border";
			} else {
				return "";
			}
		},
	},
};
</script>

<style></style>
