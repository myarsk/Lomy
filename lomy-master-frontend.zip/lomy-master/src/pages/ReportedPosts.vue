<template>
	<v-container class="posts-container" fluid>
		<v-row no-gutters>
			<v-col cols="12">
				<v-btn
					@click.prevent="
						hasHistory() ? $router.go(-1) : $router.push('/start')
					"
					color="accent"
					class="mb-4"
				>
					&laquo; {{ $vuetify.lang.t("$vuetify.back") }}
				</v-btn>
			</v-col>
			<v-col
				cols="12"
				v-for="(post, index) in allReportedPosts"
				:key="index"
				class="post-card-container"
			>
				<v-card
					:to="$router.currentRoute.path + '/' + post.id"
					:class="'post-card-wrap ' + postBodySpecial(post.postText)"
				>
					<v-card-title class="card-title">
						<v-avatar size="25">
							<img alt="user" src="/img/logo-circled.svg" />
						</v-avatar>
						<p>
							{{
								role == "ROLE_AUTHOR"
									? post.visible == "INVISIBLE"
										? $vuetify.lang.t("$vuetify.anonymous")
										: post.user.userName
									: post.user.userName
							}}
						</p>
						<v-spacer></v-spacer>
						<v-tooltip bottom color="accent">
							<template v-slot:activator="{ on, attrs }">
								<div v-bind="attrs" v-on="on">
									<v-rating
										empty-icon="mdi-star-outline"
										full-icon="mdi-star"
										half-icon="mdi-star-half-full"
										hover
										readonly
										half-increments
										length="5"
										size="25"
										:value="post.postRating"
										color="accent"
									></v-rating>
								</div>
							</template>
							<span>{{ post.postRating }}</span>
						</v-tooltip>
						<v-menu
							v-if="post.author || role != 'ROLE_AUTHOR'"
							offset-x
							:left="!$vuetify.rtl"
						>
							<template v-slot:activator="{ on, attrs }">
								<v-btn icon v-bind="attrs" v-on="on">
									<v-icon>mdi-dots-vertical</v-icon>
								</v-btn>
							</template>
							<v-list class="py-0" dense>
								<v-list-item
									@click="
										delete_dialog = true;
										delete_post = post.id;
									"
									dense
								>
									<v-list-item-title
										><v-icon size="18">mdi-delete</v-icon
										>Delete</v-list-item-title
									>
								</v-list-item>
							</v-list>
						</v-menu>
					</v-card-title>
					<v-card-text>
						<router-link
							:to="
								'/tag/' +
									$route.params.type +
									'/' +
									post.tag.tag
							"
						>
							<v-tooltip top>
								<template v-slot:activator="{ on, attrs }">
									<h2 v-bind="attrs" v-on="on">
										#{{ post.tag.tag }}
										<v-icon
											v-if="post.verified == 'VERIFIED'"
											color="blue darken-1"
											>mdi-check-decagram</v-icon
										>
									</h2>
								</template>
								<span>Click for tag info</span>
							</v-tooltip>
						</router-link>

						<p>
							{{ postBodyParser(post.postText) }}
						</p>
						<div class="post-images">
							<img
								v-for="(img, index) in post.media"
								:key="index"
								:src="'/img/uploads/' + img.media"
								class="elevation-2"
							/>
						</div>
					</v-card-text>
				</v-card>
			</v-col>
			<p class="mx-auto my-4 text-h5" v-if="empty">
				{{ $vuetify.lang.t("$vuetify.there_are_no_posts") }}
			</p>
		</v-row>
		<scroll-loader :loader-method="getPosts" :loader-disable="disable">
		</scroll-loader>
		<a href="#" @click="$vuetify.goTo(0)" class="up-btn">
			<v-icon>mdi-arrow-up-drop-circle</v-icon>
		</a>
		<v-dialog v-model="delete_dialog" max-width="290">
			<v-card>
				<v-card-title class="headline">
					{{ $vuetify.lang.t("$vuetify.confirm_delete") }}
				</v-card-title>

				<v-card-actions>
					<v-spacer></v-spacer>

					<v-btn color="secondary" @click="delete_dialog = false">
						{{ $vuetify.lang.t("$vuetify.cancel") }}
					</v-btn>

					<v-btn color="error" @click.stop="deletePost">
						{{ $vuetify.lang.t("$vuetify.delete") }}
					</v-btn>
				</v-card-actions>
			</v-card>
		</v-dialog>
	</v-container>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	name: "ReportedPosts",
	metaInfo: {
		title: "Reported Posts",
		meta: [
			{ name: "description", content: "this page is to reported posts" },
		],
	},
	data() {
		return {
			page: 0,
			disable: false,
			delete_dialog: false,
			delete_post: null,
			empty: false,
		};
	},
	computed: {
		...mapGetters(["allReportedPosts", "role"]),
	},
	methods: {
		hasHistory() {
			return window.history.length > 2;
		},
		getPosts() {
			this.$store
				.dispatch("reported_posts", {
					page: this.page++,
				})
				.then((res) => {
					if (res.data.empty) {
						this.disable = true;
						this.page == 1 ? (this.empty = true) : null;
					}
				})
				.catch((err) => {
					this.disable = true;
				});
		},
		deletePost() {
			this.$store
				.dispatch("delete_post", this.delete_post)
				.then((res) => {
					this.delete_dialog = false;
					this.hasHistory()
						? this.$router.go(-1)
						: this.$router.push("/posts");
				})
				.catch((err) => {});
			this.delete_dialog = false;
		},
		postBodyParser(str) {
			if (str.includes("/***")) {
				str = str.replace("/***", "");
				return str;
			} else if (str.includes("/*/**")) {
				str = str.replace("/*/**", "");
				return str;
			} else {
				return str;
			}
		},
		postBodySpecial(str) {
			if (str.includes("/***")) {
				return "yellow-border";
			} else if (str.includes("/*/**")) {
				return "red-border";
			} else {
				return "";
			}
		},
	},
};
</script>

<style></style>
