<template>
	<v-container class="posts-container">
		<v-row no-gutters>
			<v-col cols="12" class="d-flex align-center">
				<v-btn
					@click.prevent="
						hasHistory()
							? $router.go(-1)
							: $router.push('/posts/' + $route.params.type)
					"
					color="accent"
					class="mb-4"
				>
					&laquo; {{ $vuetify.lang.t("$vuetify.back") }}
				</v-btn>
				<v-spacer></v-spacer>
				<v-tooltip top color="accent">
					<template v-slot:activator="{ on, attrs }">
						<div v-bind="attrs" v-on="on" class="custom-switch">
							<v-switch
								class="mt-0 pt-0 d-flex align-center"
								color="accent"
								hide-details
								inset
								hint="anonymous"
								v-model="anonymous"
								:ripple="false"
							></v-switch>
							<img
								:class="anonymous ? 'right' : ''"
								:src="
									anonymous
										? '/img/anonymous.svg'
										: '/img/normal.svg'
								"
							/>
						</div>
					</template>
					<span>{{ $vuetify.lang.t("$vuetify.incognito") }}</span>
				</v-tooltip>
			</v-col>
			<v-col v-if="post[0]" cols="12" class="post-card-container">
				<v-card
					:class="
						'post-card-wrap ' + post[0].postText
							? postBodySpecial(post[0].postText)
							: ''
					"
				>
					<v-card-title class="card-title">
						<v-avatar size="25">
							<img alt="user" src="/img/logo-circled.svg" />
						</v-avatar>
						<p>
							{{
								role == "ROLE_AUTHOR"
									? post[0].visible == "INVISIBLE" ||
									  $route.params.type == "lomyo"
										? $vuetify.lang.t("$vuetify.anonymous")
										: post[0].user
										? post[0].user.userName
										: ""
									: post[0].user.userName
							}}
						</p>
						<v-spacer></v-spacer>
						<v-tooltip
							v-if="$route.params.type != 'lomyo'"
							bottom
							color="accent"
						>
							<template v-slot:activator="{ on, attrs }">
								<div v-bind="attrs" v-on="on">
									<v-rating
										v-if="$route.params.type != 'lomyo'"
										empty-icon="mdi-star-outline"
										full-icon="mdi-star"
										half-icon="mdi-star-half-full"
										hover
										readonly
										half-increments
										length="5"
										size="25"
										:value="post[0].postRating"
										color="accent"
									></v-rating>
								</div>
							</template>
							<span>{{ post[0].postRating }}</span>
						</v-tooltip>
						<v-menu
							v-if="post[0].author || role != 'ROLE_AUTHOR'"
							offset-x
							:left="!$vuetify.rtl"
						>
							<template v-slot:activator="{ on, attrs }">
								<v-btn icon v-bind="attrs" v-on="on">
									<v-icon>mdi-dots-vertical</v-icon>
								</v-btn>
							</template>
							<v-list class="py-0" dense>
								<v-list-item
									@click="
										delete_dialog = true;
										delete_post = post[0].id;
									"
									dense
								>
									<v-list-item-title
										><v-icon size="18">mdi-delete</v-icon
										>{{
											$vuetify.lang.t("$vuetify.delete")
										}}</v-list-item-title
									>
								</v-list-item>
								<v-list-item @click="reportPost" dense link>
									<v-list-item-title
										><v-icon size="18">mdi-flag</v-icon
										>{{
											$vuetify.lang.t("$vuetify.report")
										}}</v-list-item-title
									>
								</v-list-item>
							</v-list>
						</v-menu>
					</v-card-title>
					<v-card-text>
						<h2>
							<router-link
								v-if="post[0].tag"
								:to="
									'/tag/' +
										$route.params.type +
										'/' +
										post[0].tag.tag
								"
							>
								<v-tooltip top>
									<template v-slot:activator="{ on, attrs }">
										<h2 v-bind="attrs" v-on="on">
											#{{
												post[0].tag
													? post[0].tag.tag
													: ""
											}}
											<v-icon
												v-if="
													post[0].verified ==
														'VERIFIED'
												"
												color="blue darken-1"
												>mdi-check-decagram</v-icon
											>
										</h2>
									</template>
									<span>Click for tag info</span>
								</v-tooltip>
							</router-link>
						</h2>
						<p>
							{{
								post[0].postText
									? postBodyParser(post[0].postText)
									: ""
							}}
						</p>
						<div class="post-images">
							<img
								v-for="(img, index) in post[0].media"
								:key="index"
								:src="'/img/uploads/' + img.media"
								class="elevation-2"
							/>
						</div>
					</v-card-text>
					<v-card-actions>
						<v-spacer></v-spacer>
						<ShareNetwork
							class="social-icon"
							network="facebook"
							:url="currentUrl + ''"
							:title="
								post[0].postText
									? postBodyParser(post[0].postText)
									: ''
							"
							:description="postBodyParser(post[0].postText)"
							:hashtags="post[0].tag ? post[0].tag.tag : ''"
						>
							<v-btn icon>
								<img src="/img/facebook.svg" alt="" />
							</v-btn>
						</ShareNetwork>
						<ShareNetwork
							class="social-icon"
							network="twitter"
							:url="currentUrl + ''"
							:title="
								post[0].postText
									? postBodyParser(post[0].postText)
									: ''
							"
							:description="postBodyParser(post[0].postText)"
							:hashtags="post[0].tag ? post[0].tag.tag : ''"
						>
							<v-btn icon>
								<img src="/img/twitter.svg" alt="" />
							</v-btn>
						</ShareNetwork>
					</v-card-actions>
				</v-card>

				<v-card class="mt-4">
					<v-card-title class="card-title post-card-container">
						<h2>{{ $vuetify.lang.t("$vuetify.comments") }}</h2>
					</v-card-title>
					<v-card-text
						v-for="(comment, index) in allComments"
						:key="index"
						class="comment card-title"
					>
						<div class="d-flex">
							<v-avatar size="25">
								<img alt="user" src="/img/logo-circled.svg" />
							</v-avatar>
							<h2>
								{{
									role == "ROLE_AUTHOR"
										? comment.visible == "INVISIBLE"
											? $vuetify.lang.t(
													"$vuetify.anonymous",
											  )
											: comment.user.userName
										: comment.user.userName
								}}
							</h2>
							<v-spacer></v-spacer>
							<v-btn
								@click="deleteComment(comment.id)"
								icon
								fab
								x-small
								><v-icon>mdi-delete</v-icon></v-btn
							>
						</div>
						<p>
							{{ comment.comment }}
						</p>
					</v-card-text>
					<v-form
						@submit.prevent="submitComment"
						class="post-card-form pb-4 px-4"
					>
						<v-text-field
							:label="$vuetify.lang.t('$vuetify.comment')"
							v-model="comment"
							solo
							hide-details
							dense
						>
							<template v-slot:append>
								<v-btn
									min-width="18px"
									icon
									type="submit"
									color="primary"
									fab
									x-small
								>
									<v-icon>mdi-send</v-icon>
								</v-btn>
							</template>
						</v-text-field>
						<div class="flex-wrap">
							<v-btn
								@click="likePost(post[0].id)"
								:class="post[0].liked ? ' ' : ' opacity'"
								color="accent"
							>
								{{ $vuetify.lang.t("$vuetify.good") }}
								<span class="number-span">{{
									post[0].likes | formatNumber
								}}</span>
							</v-btn>
							<v-btn
								@click="dislikePost(post[0].id)"
								:class="post[0].disliked ? ' ' : ' opacity'"
								color="error"
							>
								{{ $vuetify.lang.t("$vuetify.bad") }}
								<span class="number-span">{{
									post[0].dislikes | formatNumber
								}}</span>
							</v-btn>
						</div>
					</v-form>
				</v-card>
			</v-col>
		</v-row>
		<v-dialog v-model="delete_dialog" max-width="290">
			<v-card>
				<v-card-title class="headline">
					{{ $vuetify.lang.t("$vuetify.confirm_delete") }}
				</v-card-title>

				<v-card-actions>
					<v-spacer></v-spacer>

					<v-btn color="secondary" @click="delete_dialog = false">
						{{ $vuetify.lang.t("$vuetify.cancel") }}
					</v-btn>

					<v-btn color="error" @click.stop="deletePost">
						{{ $vuetify.lang.t("$vuetify.delete") }}
					</v-btn>
				</v-card-actions>
			</v-card>
		</v-dialog>
	</v-container>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	name: "Post",
	props: ["overlay", "toggleOverlay"],
	metaInfo() {
		let title = this.post[0] ? this.post[0].tag ? this.post[0].tag.tag : "Post" : "Post";
		let description = this.post[0] ? this.post[0].postText ? this.postBodyParser(this.post[0].postText) : "" : "Post";
		return {
			title: title? title : "Post",
			meta: [
				{name: 'description', content: description? description : "The best safety way to express."},
				{name: 'og:title', property: "og:title", content: title? title : "Post"},
				{name: 'og:description', property: "og:description", content: description? description : "The best safety way to express."},
				{name: 'og:image', property: "og:image", content: '/favicon.svg'},
			]
		}
	},
	data() {
		return {
			delete_dialog: false,
			delete_post: null,
			comment: null,
			anonymous: false,
		};
	},
	async created() {
		this.toggleOverlay(true);
		await this.$store.dispatch("get_post", this.$route.params.postId);
		await this.$store
			.dispatch("get_all_comments", this.$route.params.postId)
			.then(() => {
				this.toggleOverlay(false);
			})
			.catch(() => {
				this.toggleOverlay(false);
			});
	},
	computed: {
		...mapGetters(["post", "allComments", "role"]),
		currentUrl() {
			return window.location;
		},
	},
	methods: {
		hasHistory() {
			return window.history.length > 2;
		},
		deletePost() {
			this.$store
				.dispatch("delete_post", this.$route.params.postId)
				.then((res) => {
					this.delete_dialog = false;
					this.hasHistory()
						? this.$router.go(-1)
						: this.$router.push("/posts");
				})
				.catch((err) => {});
			this.delete_dialog = false;
		},
		likePost(i) {
			this.$store.dispatch("like_post", i);
		},
		dislikePost(i) {
			this.$store.dispatch("dislike_post", i);
		},
		submitComment() {
			if (this.comment) {
				this.$store
					.dispatch("submit_comment", {
						postId: this.$route.params.postId,
						comment: this.comment,
						visible: this.anonymous ? "INVISIBLE" : "VISIBLE",
					})
					.then((res) => {
						this.comment = null;
					})
					.catch((err) => {});
			}
		},
		reportPost() {
			this.$store.dispatch("reportPost", {
				postId: this.$route.params.postId,
			});
		},
		deleteComment(id) {
			this.$store.dispatch("deleteComment", {
				commentId: id,
			});
		},
		postBodyParser(str) {
			if (str) {
				if (str.includes("/***")) {
					str = str.replace("/***", "");
					return str;
				} else if (str.includes("/*/**")) {
					str = str.replace("/*/**", "");
					return str;
				} else {
					return str;
				}
			}
		},
		postBodySpecial(str) {
			if (str) {
				if (str.includes("/***")) {
					return "yellow-border";
				} else if (str.includes("/*/**")) {
					return "red-border";
				} else {
					return "";
				}
			}
		},
	},
};
</script>

<style></style>
