<template>
	<v-container class="new-post-container" fluid>
		<v-row no-gutters>
			<v-col cols="12" class="d-flex align-center">
				<h1
					:data-aos="$vuetify.rtl ? 'fade-left' : 'fade-right'"
					class="font-weight-regular"
				>
					{{ $vuetify.lang.t("$vuetify.new_post") }}
				</h1>
				<v-spacer></v-spacer>
				<router-link
					:to="'/posts/' + $route.params.type"
					:data-aos="$vuetify.rtl ? 'fade-right' : 'fade-left'"
				>
					<h2 class="font-weight-regular">
						{{ $vuetify.lang.t("$vuetify.explore") }}
					</h2>
				</router-link>
			</v-col>
			<v-form
				@submit.prevent="rate_dialog = true"
				data-aos="fade-up"
				class="row no-gutters form-container mb-4"
			>
				<v-col cols="12" class="filters">
					<div
						class="input-container"
						:data-aos="$vuetify.rtl ? 'fade-left' : 'fade-right'"
						data-aos-delay="100"
					>
						<v-text-field
							:label="$vuetify.lang.t('$vuetify.hashtag')"
							v-model="tag"
							prefix="#"
							solo
							hide-details="auto"
							dense
							:error-messages="tagErrors"
							@input="$v.tag.$touch()"
							@blur="$v.tag.$touch()"
						></v-text-field>
					</div>
					<div
						class="input-container"
						:data-aos="$vuetify.rtl ? 'fade-left' : 'fade-right'"
						data-aos-delay="150"
					>
						<v-overflow-btn
							:items="filteredTypes"
							item-text="type"
							item-value="type"
							:label="$vuetify.lang.t('$vuetify.choose_type')"
							v-model="type"
							solo
							hide-details="auto"
							dense
							:error-messages="typeErrors"
							@input="$v.type.$touch()"
							@blur="$v.type.$touch()"
						></v-overflow-btn>
					</div>
					<div
						class="input-container"
						:data-aos="$vuetify.rtl ? 'fade-left' : 'fade-right'"
						data-aos-delay="200"
					>
						<v-overflow-btn
							:items="allCountries"
							item-text="country"
							item-value="country"
							:label="$vuetify.lang.t('$vuetify.country')"
							prepend-inner-icon="mdi-earth"
							v-model="country"
							solo
							hide-details="auto"
							dense
							:error-messages="countryErrors"
							@input="$v.country.$touch()"
							@blur="$v.country.$touch()"
						></v-overflow-btn>
					</div>
					<v-spacer></v-spacer>
					<v-tooltip top color="accent">
						<template v-slot:activator="{ on, attrs }">
							<div v-bind="attrs" v-on="on" class="custom-switch">
								<v-switch
									class="mt-0 pt-0 d-flex align-center"
									color="accent"
									hide-details
									inset
									hint="anonymous"
									v-model="anonymous"
									:ripple="false"
								></v-switch>
								<img
									:class="anonymous ? 'right' : ''"
									:src="
										anonymous
											? '/img/anonymous.svg'
											: '/img/normal.svg'
									"
								/>
							</div>
						</template>
						<span>{{ $vuetify.lang.t("$vuetify.incognito") }}</span>
					</v-tooltip>
				</v-col>
				<v-col
					:data-aos="$vuetify.rtl ? 'fade-left' : 'fade-right'"
					data-aos-delay="250"
					cols="12"
				>
					<v-textarea
						:label="$vuetify.lang.t('$vuetify.write_your_opinion')"
						v-model="body"
						solo
						hide-details="auto"
						class="mb-3"
						no-resize
						rows="6"
						:error-messages="bodyErrors"
						@input="$v.body.$touch()"
						@blur="$v.body.$touch()"
					></v-textarea>
				</v-col>
				<v-col cols="12" class="d-flex">
					<div class="bad-words-container">
						<v-chip
							v-for="(word, index) in bad_words"
							:key="index"
							close
							color="error"
							@click:close="removeWord(word)"
						>
							{{ word }}
						</v-chip>
					</div>
					<v-spacer></v-spacer>
					<v-file-input
						class="flex-grow-0 mx-3"
						dense
						small-chips
						multiple
						solo
						v-model="images"
					></v-file-input>
					<v-btn color="accent" type="submit">{{
						$vuetify.lang.t("$vuetify.post")
					}}</v-btn>
				</v-col>
			</v-form>
			<v-col cols="12">
				<router-link to="/">
					<v-img
						class="mt-auto ad"
						src="https://www.adspeed.com/placeholder-728x90-Test.gif"
					/>
				</router-link>
			</v-col>
		</v-row>
		<v-dialog v-model="rate_dialog" max-width="290">
			<v-card>
				<v-card-title class="headline justify-center">
					{{
						$route.params.type == "opinions"
							? $vuetify.lang.t("$vuetify.your_rating")
							: $vuetify.lang.t("$vuetify.create")
					}}
					<v-tooltip
						v-if="$route.params.type == 'opinions'"
						bottom
						color="accent"
					>
						<template v-slot:activator="{ on, attrs }">
							<div v-bind="attrs" v-on="on">
								<v-rating
									empty-icon="mdi-star-outline"
									full-icon="mdi-star"
									half-icon="mdi-star-half-full"
									hover
									half-increments
									length="5"
									size="25"
									v-model="rating"
									color="accent"
								></v-rating>
							</div>
						</template>
						<span>{{ rating }}</span>
					</v-tooltip>
				</v-card-title>

				<v-card-actions>
					<v-spacer></v-spacer>

					<v-btn color="secondary" @click="rate_dialog = false">
						{{ $vuetify.lang.t("$vuetify.cancel") }}
					</v-btn>

					<v-btn color="accent" @click.stop="newPost">
						{{ $vuetify.lang.t("$vuetify.post") }}
					</v-btn>
				</v-card-actions>
			</v-card>
		</v-dialog>
	</v-container>
</template>

<script>
import { mapGetters } from "vuex";
import { validationMixin } from "vuelidate";
import {
	required,
	maxLength,
	minLength,
	email,
} from "vuelidate/lib/validators";
// import axios from '../plugins/axios.js';

export default {
	name: "NewPost",
	metaInfo: {
		title: "New post",
		meta: [{ name: "description", content: "this is the new post" }],
	},
	mixins: [validationMixin],
	validations: {
		tag: { required, maxLength: maxLength(20), minLength: minLength(3) },
		type: { required },
		country: { required },
		body: { required },
	},
	props: ["overlay", "toggleOverlay"],
	data() {
		return {
			anonymous: false,
			tag: null,
			type: null,
			country: null,
			images: null,
			body: null,
			rating: 0,
			rate_dialog: false,
			bad_words: [],
		};
	},
	created() {
		this.$store.dispatch("fetch_countries");
		this.$store.dispatch("fetch_types");
		this.$store.dispatch("getAllAds");
	},
	computed: {
		...mapGetters(["allCountries", "allTypes", "getAd"]),
		filteredTypes() {
			let temp = [];
			if (this.$route.params.type == "opinions") {
				temp = this.allTypes.filter((type) =>
					type.type
						? type.type != "mistakes" &&
						  type.type != "problems" &&
						  type.type != "secrets"
						: false,
				);
			} else {
				temp = this.allTypes.filter((type) =>
					type.type
						? type.type == "mistakes" ||
						  type.type == "problems" ||
						  type.type == "secrets"
						: false,
				);
			}
			return temp;
		},
		tagErrors() {
			const errors = [];
			if (!this.$v.tag.$dirty) return errors;
			!this.$v.tag.maxLength &&
				errors.push(
					this.$vuetify.lang.t("$vuetify.tag") +
						" " +
						this.$vuetify.lang.t("$vuetify.must_be_at_most") +
						" 20 " +
						this.$vuetify.lang.t("$vuetify.characters_long") +
						".",
				);
			!this.$v.tag.minLength &&
				errors.push(
					this.$vuetify.lang.t("$vuetify.tag") +
						" " +
						this.$vuetify.lang.t("$vuetify.must_be_at_least") +
						" 3 " +
						this.$vuetify.lang.t("$vuetify.characters_long") +
						".",
				);
			!this.$v.tag.required &&
				errors.push(
					this.$vuetify.lang.t("$vuetify.tag") +
						" " +
						this.$vuetify.lang.t("$vuetify.is_required") +
						".",
				);
			return errors;
		},
		typeErrors() {
			const errors = [];
			if (!this.$v.type.$dirty) return errors;
			!this.$v.type.required &&
				errors.push(
					this.$vuetify.lang.t("$vuetify.type") +
						" " +
						this.$vuetify.lang.t("$vuetify.is_required") +
						".",
				);
			return errors;
		},
		countryErrors() {
			const errors = [];
			if (!this.$v.country.$dirty) return errors;
			!this.$v.country.required &&
				errors.push(
					this.$vuetify.lang.t("$vuetify.country") +
						" " +
						this.$vuetify.lang.t("$vuetify.is_required") +
						".",
				);
			return errors;
		},
		bodyErrors() {
			const errors = [];
			if (!this.$v.body.$dirty) return errors;
			!this.$v.body.required &&
				errors.push(
					this.$vuetify.lang.t("$vuetify.body") +
						" " +
						this.$vuetify.lang.t("$vuetify.is_required") +
						".",
				);
			return errors;
		},
	},
	methods: {
		async newPost() {
            this.rate_dialog = false;
			this.toggleOverlay(true);
			this.$v.$touch();
			console.log(this.images);
			if (!this.$v.$invalid) {
				var form = new FormData();
				form.append(
					"visible",
					this.anonymous ? "INVISIBLE" : "VISIBLE",
				);
				form.append("country", this.country);
				form.append("tag", this.tag);
				form.append("type", this.type);
				form.append("rating", this.rating);
				form.append("postText", this.body);
				// if(this.images) form.append("files", this.images);
				if(this.images) {
					for (var i = 0; i < this.images.length; i++) {
						let file = this.images[i];
						console.log(file);
						form.append("files", file);
					}
				}
				form.append(
					"isExperience",
					this.$route.params.type == "opinions",
				);
				console.log(form.values());
				await this.$axios({
					method: "post",
					url: "post/create/",
					data: form,
					headers: {
						"Content-Type": "multipart/form-data",
					},
				})
					// this.$store.dispatch('new_post', form)
					.then((res) => {
						this.toggleOverlay(false);
						this.$router.push("/posts/"+this.$route.params.type);
					})
					.catch((err) => {
						this.toggleOverlay(false);
						if (Array.isArray(err.response.data)) {
							console.log(err.response.data);
							this.bad_words = err.response.data;
						}
					});
			} else {
				this.toggleOverlay(false);
			}
		},
		removeWord(word) {
			this.body = this.body.replace(
				new RegExp("\\b" + word + "\\b", "g"),
				"",
			);
			this.bad_words = this.bad_words.filter((e) => e !== word);
		},
	},
	// created() {
	//     console.log(this.$vuetify.direction)
	// }
};
</script>

<style></style>
