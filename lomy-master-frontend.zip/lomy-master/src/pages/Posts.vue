<template>
	<v-container class="posts-container" fluid>
		<v-form @submit.prevent="searchFilters" class="row no-gutters">
			<v-col cols="12" class="d-flex align-center">
				<h1>{{ $vuetify.lang.t("$vuetify.explore") }}</h1>
				<v-spacer></v-spacer>
				<v-tooltip
					top
					v-if="role && role != 'ROLE_AUTHOR'"
					color="scroll"
				>
					<template v-slot:activator="{ on, attrs }">
						<v-btn
							to="/posts/pending_posts"
							v-on="on"
							v-bind="attrs"
							color="scroll"
							elevation="1"
							fab
							x-small
							dark
						>
							<v-icon>mdi-timer-sand</v-icon>
						</v-btn>
					</template>
					<span>{{ $vuetify.lang.t("$vuetify.pending_posts") }}</span>
				</v-tooltip>
				<v-tooltip
					top
					v-if="role && role != 'ROLE_AUTHOR'"
					color="error"
				>
					<template v-slot:activator="{ on, attrs }">
						<v-btn
							to="/posts/reported_posts"
							v-on="on"
							v-bind="attrs"
							color="error"
							class="mx-4"
							elevation="1"
							fab
							x-small
							dark
						>
							<v-icon>mdi-flag</v-icon>
						</v-btn>
					</template>
					<span>{{
						$vuetify.lang.t("$vuetify.reported_posts")
					}}</span>
				</v-tooltip>
				<v-tooltip top color="accent">
					<template v-slot:activator="{ on, attrs }">
						<div v-bind="attrs" v-on="on" class="custom-switch">
							<v-switch
								class="mt-0 pt-0 d-flex align-center"
								color="accent"
								hide-details
								inset
								hint="anonymous"
								v-model="anonymous"
								:ripple="false"
							></v-switch>
							<img
								:class="anonymous ? 'right' : ''"
								:src="
									anonymous
										? '/img/anonymous.svg'
										: '/img/normal.svg'
								"
							/>
						</div>
					</template>
					<span>{{ $vuetify.lang.t("$vuetify.incognito") }}</span>
				</v-tooltip>
			</v-col>
			<div class="filters">
				<v-overflow-btn
					:items="filteredTypes"
					item-text="type"
					item-value="type"
					:label="$vuetify.lang.t('$vuetify.choose_type')"
					v-model="search.type"
					solo
					hide-details="auto"
					dense
				></v-overflow-btn>
				<v-overflow-btn
					:items="allCountries"
					item-text="country"
					item-value="country"
					:label="$vuetify.lang.t('$vuetify.country')"
					prepend-inner-icon="mdi-earth"
					v-model="search.country"
					solo
					hide-details="auto"
					dense
				></v-overflow-btn>
				<v-spacer></v-spacer>
				<v-text-field
					:label="$vuetify.lang.t('$vuetify.search')"
					append-icon="mdi-magnify"
					v-model.lazy="tag"
					solo
					hide-details="auto"
					dense
				></v-text-field>
				<v-btn
					:to="$router.currentRoute.path + '/new_post'"
					color="scroll"
					class="new-btn"
				>
					{{ $vuetify.lang.t("$vuetify.new") }}
				</v-btn>
			</div>
		</v-form>
		<v-row>
			<v-row
				v-if="allPostsCustom.length > 0"
				class="col-12 col-md-10"
				no-gutters
			>
				<v-col
					cols="12"
					v-for="(post, index) in allPostsCustom"
					:key="index"
					class="post-card-container"
				>
					<v-card
						:to="$router.currentRoute.path + '/' + post.id"
						@click="
							$router.push(
								$router.currentRoute.path + '/' + post.id,
							)
						"
						:class="
							'post-card-wrap ' + postBodySpecial(post.postText)
						"
					>
						<v-card-title class="card-title">
							<v-avatar size="25">
								<img alt="user" src="/img/logo-circled.svg" />
							</v-avatar>
							<p>
								{{
									role == "ROLE_AUTHOR"
										? post.visible == "INVISIBLE" ||
										  $route.params.type == "lomyo"
											? $vuetify.lang.t(
													"$vuetify.anonymous",
											  )
											: post.user.userName
										: post.user.userName
								}}
							</p>
							<v-spacer></v-spacer>
							<v-tooltip
								v-if="$route.params.type == 'opinions'"
								bottom
								color="accent"
							>
								<template v-slot:activator="{ on, attrs }">
									<div v-bind="attrs" v-on="on">
										<v-rating
											empty-icon="mdi-star-outline"
											full-icon="mdi-star"
											half-icon="mdi-star-half-full"
											hover
											readonly
											half-increments
											length="5"
											size="25"
											:value="post.postRating"
											color="accent"
										></v-rating>
									</div>
								</template>
								<span>{{ post.postRating }}</span>
							</v-tooltip>
						</v-card-title>
						<v-card-text>
							<router-link
								:to="
									'/tag/' +
										$route.params.type +
										'/' +
										post.tag.tag
								"
							>
								<v-tooltip top>
									<template v-slot:activator="{ on, attrs }">
										<h2 v-bind="attrs" v-on="on">
											#{{ post.tag.tag }}
											<v-icon
												v-if="
													post.verified == 'VERIFIED'
												"
												color="blue darken-1"
												>mdi-check-decagram</v-icon
											>
										</h2>
									</template>
									<span>Click for tag info</span>
								</v-tooltip>
							</router-link>
							<p>
								{{ postBodyParser(post.postText) }}
							</p>
							<div class="post-images">
								<img
									v-for="(img, index) in post.media"
									:key="index"
									:src="'/img/uploads/' + img.media"
									class="elevation-2"
								/>
							</div>
						</v-card-text>
						<v-card-actions>
							<v-spacer></v-spacer>
							<ShareNetwork
								class="social-icon"
								network="facebook"
								:url="currentUrl + '/' + post.id"
								:title="postBodyParser(post.postText)"
								:description="postBodyParser(post.postText)"
								:hashtags="post.tag.tag"
							>
								<v-btn icon>
									<img src="/img/facebook.svg" alt="" />
								</v-btn>
							</ShareNetwork>
							<ShareNetwork
								class="social-icon"
								network="twitter"
								:url="currentUrl + '/' + post.id"
								:title="postBodyParser(post.postText)"
								:description="postBodyParser(post.postText)"
								:hashtags="post.tag.tag"
							>
								<v-btn icon>
									<img src="/img/twitter.svg" alt="" />
								</v-btn>
							</ShareNetwork>
						</v-card-actions>
					</v-card>
					<v-form
						@submit.prevent="submitComment(post.id, index)"
						class="post-card-form pb-4"
					>
						<v-text-field
							v-if="comments[index]"
							:label="$vuetify.lang.t('$vuetify.comment')"
							v-model="comments[index].comment"
							solo
							hide-details
							dense
						>
							<template v-slot:append>
								<v-btn
									min-width="18px"
									icon
									type="submit"
									color="primary"
									fab
									x-small
								>
									<v-icon>mdi-send</v-icon>
								</v-btn>
							</template>
						</v-text-field>
						<div class="flex-wrap">
							<v-btn
								@click="likePost(post.id)"
								:class="post.liked ? ' ' : ' opacity'"
								color="accent"
							>
								{{ $vuetify.lang.t("$vuetify.good") }}
								<span class="number-span">{{
									post.likes | formatNumber
								}}</span>
							</v-btn>
							<v-btn
								@click="dislikePost(post.id)"
								:class="post.disliked ? '' : 'opacity'"
								color="error"
							>
								{{ $vuetify.lang.t("$vuetify.bad") }}
								<span class="number-span">{{
									post.dislikes | formatNumber
								}}</span>
							</v-btn>
						</div>
					</v-form>
				</v-col>
				<p class="mx-auto my-4 text-h5" v-if="empty">
					{{ $vuetify.lang.t("$vuetify.there_are_no_posts") }}
				</p>
			</v-row>
			<v-row
				v-else-if="allTags.length > 0"
				class="col-12 col-md-10"
				no-gutters
			>
				<v-col v-if="allTags[0]" cols="12" class="post-card-container">
					<v-card
						class="post-card-wrap"
						:to="
							'/tag/' +
								$route.params.type +
								'/' +
								allTags[0].tag.tag
						"
					>
						<v-card-title class="card-title">
							<h2 class="mb-0">
								#{{ allTags[0].tag.tag }}
								<v-icon
									v-if="allTags.verified == 'VERIFIED'"
									color="blue darken-1"
									>mdi-check-decagram</v-icon
								>
							</h2>
							<v-spacer></v-spacer>
							({{
								$formatDecimal(allTags[0].tag.numberOfRaters == 0
									? 0
									: allTags[0].tag.rating /
									allTags[0].tag.numberOfRaters)
							}})
							<v-tooltip bottom color="accent">
								<template v-slot:activator="{ on, attrs }">
									<div v-bind="attrs" v-on="on">
										<v-rating
											empty-icon="mdi-star-outline"
											full-icon="mdi-star"
											half-icon="mdi-star-half-full"
											hover
											readonly
											half-increments
											length="5"
											size="25"
											:value=" parseFloat (
												$formatDecimal(allTags[0].tag.numberOfRaters == 0
													? 0
													: allTags[0].tag.rating /
													allTags[0].tag.numberOfRaters)
											)"
											color="accent"
										></v-rating>
									</div>
								</template>
								<span>{{
									$formatDecimal(allTags[0].tag.numberOfRaters == 0
										? 0
										: allTags[0].tag.rating /
										allTags[0].tag.numberOfRaters)
								}}</span>
							</v-tooltip>
						</v-card-title>
					</v-card>
				</v-col>
				<v-col
					cols="12"
					v-for="(post, index) in allTags"
					:key="index"
					class="post-card-container"
				>
					<v-card
						:to="$router.currentRoute.path + '/' + post.id"
						@click="
							$router.push(
								$router.currentRoute.path + '/' + post.id,
							)
						"
						:class="
							'post-card-wrap ' + postBodySpecial(post.postText)
						"
					>
						<v-card-title class="card-title">
							<v-avatar size="25">
								<img alt="user" src="/img/logo-circled.svg" />
							</v-avatar>
							<p>
								{{
									role == "ROLE_AUTHOR"
										? post.visible == "INVISIBLE" ||
										  $route.params.type == "lomyo"
											? $vuetify.lang.t(
													"$vuetify.anonymous",
											  )
											: post.user.userName
										: post.user.userName
								}}
							</p>
							<v-spacer></v-spacer>
							<v-tooltip
								v-if="$route.params.type == 'opinions'"
								bottom
								color="accent"
							>
								<template v-slot:activator="{ on, attrs }">
									<div v-bind="attrs" v-on="on">
										<v-rating
											empty-icon="mdi-star-outline"
											full-icon="mdi-star"
											half-icon="mdi-star-half-full"
											hover
											readonly
											half-increments
											length="5"
											size="25"
											:value="post.postRating"
											color="accent"
										></v-rating>
									</div>
								</template>
								<span>{{ post.postRating }}</span>
							</v-tooltip>
						</v-card-title>
						<v-card-text>
							<router-link
								:to="
									'/tag/' +
										$route.params.type +
										'/' +
										post.tag.tag
								"
							>
								<v-tooltip top>
									<template v-slot:activator="{ on, attrs }">
										<h2 v-bind="attrs" v-on="on">
											#{{ post.tag.tag }}
											<v-icon
												v-if="
													post.verified == 'VERIFIED'
												"
												color="blue darken-1"
												>mdi-check-decagram</v-icon
											>
										</h2>
									</template>
									<span>Click for tag info</span>
								</v-tooltip>
							</router-link>
							<p>
								{{ postBodyParser(post.postText) }}
							</p>
							<div class="post-images">
								<img
									v-for="(img, index) in post.media"
									:key="index"
									:src="'/img/uploads/' + img.media"
									class="elevation-2"
								/>
							</div>
						</v-card-text>
						<v-card-actions>
							<v-spacer></v-spacer>
							<ShareNetwork
								class="social-icon"
								network="facebook"
								:url="currentUrl + '/' + post.id"
								:title="postBodyParser(post.postText)"
								:description="postBodyParser(post.postText)"
								:hashtags="post.tag.tag"
							>
								<v-btn icon>
									<img src="/img/facebook.svg" alt="" />
								</v-btn>
							</ShareNetwork>
							<ShareNetwork
								class="social-icon"
								network="twitter"
								:url="currentUrl + '/' + post.id"
								:title="postBodyParser(post.postText)"
								:description="postBodyParser(post.postText)"
								:hashtags="post.tag.tag"
							>
								<v-btn icon>
									<img src="/img/twitter.svg" alt="" />
								</v-btn>
							</ShareNetwork>
						</v-card-actions>
					</v-card>
					<v-form
						@submit.prevent="submitComment(post.id, index)"
						class="post-card-form pb-4"
					>
						<v-text-field
							v-if="comments[index]"
							:label="$vuetify.lang.t('$vuetify.comment')"
							v-model="comments[index].comment"
							solo
							hide-details
							dense
						>
							<template v-slot:append>
								<v-btn
									min-width="18px"
									icon
									type="submit"
									color="primary"
									fab
									x-small
								>
									<v-icon>mdi-send</v-icon>
								</v-btn>
							</template>
						</v-text-field>
						<div class="flex-wrap">
							<v-btn
								@click="likePost(post.id)"
								:class="post.liked ? ' ' : ' opacity'"
								color="accent"
							>
								{{ $vuetify.lang.t("$vuetify.good") }}
								<span class="number-span">{{
									post.likes | formatNumber
								}}</span>
							</v-btn>
							<v-btn
								@click="dislikePost(post.id)"
								:class="post.disliked ? '' : 'opacity'"
								color="error"
							>
								{{ $vuetify.lang.t("$vuetify.bad") }}
								<span class="number-span">{{
									post.dislikes | formatNumber
								}}</span>
							</v-btn>
						</div>
					</v-form>
				</v-col>
			</v-row>
			<v-col
				v-if="allPostsCustom.length > 0 || allTags.length > 0"
				class="ad-container"
				cols="12"
				md="2"
			>
				<!-- {{getAd}} -->
				<router-link to="/">
					<img
						class="ad"
						src="https://www.adspeed.com/placeholder-123x456.gif"
						alt=""
					/>
				</router-link>
			</v-col>
		</v-row>

		<scroll-loader
			v-if="allPostsCustom"
			:loader-method="getPosts"
			:loader-disable="disable"
		>
		</scroll-loader>
		<scroll-loader
			v-if="allTags"
			:loader-method="filterByTag"
			:loader-disable="disableTags"
		>
		</scroll-loader>
		<a href="#" @click="$vuetify.goTo(0)" class="up-btn">
			<v-icon>mdi-arrow-up-drop-circle</v-icon>
		</a>
	</v-container>
</template>

<script>
import { mapGetters } from "vuex";

export default {
	name: "Posts",
	metaInfo: {
		title: "Posts",
		meta: [{ name: "description", content: "this is the posts page" }],
	},
	data() {
		return {
			disable: false,
			disableTags: true,
			delete_dialog: false,
			delete_post: null,
			page: 0,
			tagPage: 0,
			pageSize: 10,
			rating: 0,
			anonymous: false,
			search: {
				type: null,
				country: null,
			},
			tag: null,
			empty: false,
			comments: [],
		};
	},
	watch: {
		rating: function() {
			this.submitRate();
		},
		search: {
			handler() {
				this.page = 0;
				this.tagPage = 0;
				this.empty = false;
				this.disable = false;
				this.disableTags = true;
				let data = {
					country: this.search.country,
					type: this.search.type,
					isExperience:
						this.$route.params.type == "opinions" ? true : false,
					page: this.page++,
				};
				this.clean(data);
				this.$store
					.dispatch("all_posts", data)
					.then((res) => {
						this.empty = false;
					})
					.catch((err) => {
						this.page == 1 ? (this.empty = true) : null;
						this.disable = true;
					});
			},
			deep: true,
		},
		tag: {
			handler(val) {
				this.page = 0;
				this.tagPage = 0;
				this.empty = false;
				this.disable = true;
				this.disableTags = false;
				this.search.country = null;
				this.search.type = null;
				if (val == "" || val == null) {
					this.disable = false;
					this.disableTags = true;
				}
				this.filterByTag(val);
			},
		},
	},
	async created() {
		await this.$store.dispatch("fetch_countries");
		await this.$store.dispatch("fetch_types");
		await this.$store.dispatch("getAllAds");
	},
	computed: {
		...mapGetters([
			"allPosts",
			"allCountries",
			"allTypes",
			"role",
			"allTagPosts",
			"getAd",
		]),
		filteredTypes() {
			let temp = [];
			if (this.$route.params.type == "opinions") {
				temp = this.allTypes.filter((type) =>
					type.type
						? type.type != "mistakes" &&
						  type.type != "problems" &&
						  type.type != "secrets"
						: false,
				);
			} else {
				temp = this.allTypes.filter((type) =>
					type.type
						? type.type == "mistakes" ||
						  type.type == "problems" ||
						  type.type == "secrets"
						: false,
				);
			}
			return temp;
		},
		currentUrl() {
			return window.location;
		},
		allPostsCustom() {
			this.comments = [];
			for (let index = 0; index < this.allPosts.length; index++) {
				const element = this.allPosts[index];
				this.comments = [
					...this.comments,
					{
						comment: null,
					},
				];
			}
			return this.allPosts;
		},
		allTags() {
			this.comments = [];
			for (let index = 0; index < this.allTagPosts.length; index++) {
				const element = this.allTagPosts[index];
				this.comments = [
					...this.comments,
					{
						comment: null,
					},
				];
			}
			return this.allTagPosts;
		},
	},
	methods: {
		getPosts() {
			let data = {
				country: this.search.country,
				type: this.search.type,
				isExperience:
					this.$route.params.type == "opinions" ? true : false,
				page: this.page++,
			};
			this.clean(data);
			this.$store
				.dispatch("all_posts", data)
				.then((res) => {
					this.empty = false;
				})
				.catch((err) => {
					this.page == 1 ? (this.empty = true) : null;
					this.disable = true;
				});
		},
		likePost(i) {
			this.$store.dispatch("like_post", i);
		},
		dislikePost(i) {
			this.$store.dispatch("dislike_post", i);
		},
		deletePost() {
			this.delete_dialog = false;
		},
		filterByTag() {
			this.$store
				.dispatch("filterby_tag", {
					tag: this.tag,
					isExperience:
						this.$route.params.type == "opinions" ? true : false,
					page: this.tagPage++,
				})
				.then((res) => {
					this.empty = false;
				})
				.catch((err) => {
					this.tagPage == 1 ? (this.empty = true) : null;
					this.disableTags = true;
				});
		},
		submitComment(postId, index) {
			if (this.comments[index]) {
				this.$store
					.dispatch("submit_comment", {
						postId: postId,
						comment: this.comments[index].comment,
						visible: this.anonymous ? "INVISIBLE" : "VISIBLE",
					})
					.then((res) => {
						this.comments[index].comment = null;
					})
					.catch((err) => {});
			}
		},
		postBodyParser(str) {
			if (str.includes("/***")) {
				str = str.replace("/***", "");
				return str;
			} else if (str.includes("/*/**")) {
				str = str.replace("/*/**", "");
				return str;
			} else {
				return str;
			}
		},
		postBodySpecial(str) {
			if (str.includes("/***")) {
				return "yellow-border";
			} else if (str.includes("/*/**")) {
				return "red-border";
			} else {
				return "";
			}
		},
		clean(obj) {
			for (var propName in obj) {
				if (obj[propName] === null || obj[propName] === undefined) {
					delete obj[propName];
				}
			}
			return obj;
		},
	},
};
</script>

<style></style>
