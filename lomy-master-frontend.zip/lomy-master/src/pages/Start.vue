<template>
	<v-container class="start-container" fluid>
		<v-row>
			<v-col
				:data-aos="$vuetify.rtl ? 'fade-left' : 'fade-right'"
				class="content-wrap"
				cols="7"
				md="7"
			>
				<h1 class="font-weight-regular">
					{{ $vuetify.lang.t("$vuetify.pick_genre") }}
				</h1>
				<!-- data-aos="fade-up" data-aos-delay="200" data-aos-offset="-300" -->
				<!-- <v-btn to="/posts/criticism" color="input">{{ $vuetify.lang.t("$vuetify.criticism") }}</v-btn> -->
				<div>
					<v-btn to="/posts/opinions" color="input">{{
						$vuetify.lang.t("$vuetify.opinions")
					}}</v-btn>
					<v-btn
						data-aos-offset="-300"
						to="/posts/lomyo"
						color="accent"
						>{{ $vuetify.lang.t("$vuetify.lomyo") }}</v-btn
					>
				</div>
			</v-col>
			<v-col
				:data-aos="$vuetify.rtl ? 'fade-right' : 'fade-left'"
				class="img-wrap"
				cols="5"
				md="5"
			>
				<img src="/img/carect3.svg" />
			</v-col>
			<v-col cols="12">
                <router-link to="/">
                    <v-img
                        class="mt-auto ad"
                        src="https://www.adspeed.com/placeholder-728x90-Test.gif"
                    />
                </router-link>
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
import { mapGetters } from "vuex";

export default {
	name: "Start",
	metaInfo: {
		title: "Start",
		meta: [{ name: "description", content: "this is the start page" }],
	},
	created() {
		this.$store.dispatch("getAllAds");
	},
	computed: {
		...mapGetters(["getAd"]),
	},
};
</script>

<style></style>
