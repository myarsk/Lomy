<template>
    <div class="contactUs">
        <v-container fluid>
			<v-row class="content-section section1">
                <v-col cols="12" :data-aos="$vuetify.rtl? 'fade-left': 'fade-right'" class="content-wrap">
                    <span class="themed-circle"></span>
                    <div class="content-text">
                        <h1 data-aos="fade-up" data-aos-delay="100">{{ $vuetify.lang.t("$vuetify.contact") }}</h1>
                        <p data-aos="fade-up" data-aos-delay="200">{{ $vuetify.lang.t("$vuetify.contact_desc") }}</p>
						<p data-aos="fade-up" data-aos-delay="300" class="contact-with-us">{{ $vuetify.lang.t("$vuetify.contact_with_us") }}</p>
						<p data-aos="fade-up" data-aos-delay="400" class="email"><span>lomyinfo@gmail.com</span></p>
                    </div>
					<div class="follow-us" data-aos="fade-up" data-aos-offset="-300" data-aos-delay="600">
						<div class="yellow-circle"></div>
						{{ $vuetify.lang.t("$vuetify.follow_us") }}
						<div class="media">
							<a href="#"><img src="/img/facebook.svg" alt="" /></a>
							<a href="#"
								><img src="/img/instagram-sketched.svg" alt=""
							/></a>
							<a href="#"><img src="/img/twitter.svg" alt="" /></a>
						</div>
					</div>
                </v-col>
                <div :data-aos="$vuetify.rtl? 'fade-right': 'fade-left'" data-aos-delay="200" class="img-wrap">
                    <img src="/img/caret footer.svg" />
                </div>
            </v-row>
            <!-- <v-row class="section">
                <div class="col-md-9 sec-text">
                    <div class="circle1"></div>
                    <div class="circle2"></div>
                    <h1>Contact us</h1>
                    <p>
                        Because we are curious to know your opinion about your
                        experience in our platform or to contact with us about
                        anything we would be happy to receive from you
                    </p>
                    <div class="contact-with-us">Contact with us :</div>
                    <div class="email"><span>lomy@gmail.com</span></div>
                </div>
                <div class="col-md-3 sec1-img sec-img">
                    <img src="svgs/caret footer.svg" alt="" />
                </div>

                <div class="follow-us">
                    <div class="yellow-circle"></div>
                    Follow us
                    <div class="media">
                        <a href="#"><img src="svgs/facebook1.svg" alt="" /></a>
                        <a href="#"
                            ><img src="svgs/instagram-sketched1.svg" alt=""
                        /></a>
                        <a href="#"><img src="svgs/twitter1.svg" alt="" /></a>
                    </div>
                </div>
            </v-row> -->
        </v-container>
    </div>
</template>

<script>
export default {
    name: "Contact",
    metaInfo: {
        title: 'Contact us',
        meta: [
            {name: 'description', content: 'this is the contact us'}
        ]
    },
};
</script>
