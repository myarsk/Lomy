<template>
	<v-container class="posts-container" fluid>
		<v-row no-gutters>
			<v-col cols="12">
				<v-btn
					@click.prevent="
						hasHistory() ? $router.go(-1) : $router.push('/start')
					"
					color="accent"
					class="mb-4"
				>
					&laquo; {{ $vuetify.lang.t("$vuetify.back") }}
				</v-btn>
			</v-col>
			<v-col
				cols="12"
				v-for="(post, index) in allPendingPosts"
				:key="index"
				class="post-card-container row no-gutters"
			>
				<v-card
					:to="$router.currentRoute.path + '/' + post.id"
					:class="
						'post-card-wrap col-12 ' +
							postBodySpecial(post.postText)
					"
				>
					<v-card-title class="card-title">
						<v-avatar size="25">
							<img alt="user" src="/img/logo-circled.svg" />
						</v-avatar>
						<p>
							{{
								role == "ROLE_AUTHOR"
									? post.visible == "INVISIBLE"
										? $vuetify.lang.t("$vuetify.anonymous")
										: post.user.userName
									: post.user.userName
							}}
						</p>
						<v-spacer></v-spacer>
						<v-tooltip bottom color="accent">
							<template v-slot:activator="{ on, attrs }">
								<div v-bind="attrs" v-on="on">
									<v-rating
										empty-icon="mdi-star-outline"
										full-icon="mdi-star"
										half-icon="mdi-star-half-full"
										hover
										readonly
										half-increments
										length="5"
										size="25"
										:value="post.postRating"
										color="accent"
									></v-rating>
								</div>
							</template>
							<span>{{ post.postRating }}</span>
						</v-tooltip>
					</v-card-title>
					<v-card-text>
						<router-link
							:to="
								'/tag/' +
									$route.params.type +
									'/' +
									post.tag.tag
							"
						>
							<v-tooltip top>
								<template v-slot:activator="{ on, attrs }">
									<h2 v-bind="attrs" v-on="on">
										#{{ post.tag.tag }}
										<v-icon
											v-if="post.verified == 'VERIFIED'"
											color="blue darken-1"
											>mdi-check-decagram</v-icon
										>
									</h2>
								</template>
								<span>Click for tag info</span>
							</v-tooltip>
						</router-link>

						<p>
							{{ postBodyParser(post.postText) }}
						</p>
						<div class="post-images">
							<img
								v-for="(img, index) in post.media"
								:key="index"
								:src="'/img/uploads/' + img.media"
								class="elevation-2"
							/>
						</div>
					</v-card-text>
				</v-card>
				<v-col cols="12" class="d-flex">
					<v-spacer></v-spacer>
					<v-btn
						min-width="200"
						@click="acceptPost(post.id)"
						class="mx-4"
						color="accent"
					>
						{{ $vuetify.lang.t("$vuetify.accept_post") }}
					</v-btn>
					<v-btn
						min-width="200"
						@click="rejectPost(post.id)"
						color="error"
					>
						{{ $vuetify.lang.t("$vuetify.reject_post") }}
					</v-btn>
				</v-col>
			</v-col>
			<p class="mx-auto my-4 text-h5" v-if="empty">
				{{ $vuetify.lang.t("$vuetify.there_are_no_posts") }}
			</p>
		</v-row>
		<scroll-loader :loader-method="getPosts" :loader-disable="disable">
		</scroll-loader>
		<a href="#" @click="$vuetify.goTo(0)" class="up-btn">
			<v-icon>mdi-arrow-up-drop-circle</v-icon>
		</a>
	</v-container>
</template>

<script>
import { mapGetters } from "vuex";
export default {
	name: "PendingPosts",
	metaInfo: {
		title: "Pending Posts",
		meta: [
			{ name: "description", content: "this page is to pending posts" },
		],
	},
	data() {
		return {
			page: 0,
			disable: false,
			empty: false,
		};
	},
	computed: {
		...mapGetters(["allPendingPosts", "role"]),
	},
	methods: {
		hasHistory() {
			return window.history.length > 2;
		},
		getPosts() {
			this.$store
				.dispatch("pending_posts", {
					page: this.page++,
				})
				.then((res) => {
					this.empty = false;
					if (res.data.empty) {
						this.disable = true;
						this.page == 1 ? (this.empty = true) : null;
					}
				})
				.catch((err) => {
					this.disable = true;
				});
		},
		acceptPost(id) {
			this.$store
				.dispatch("accept_post", {
					postId: id,
				})
				.then((res) => {})
				.catch((err) => {});
		},
		rejectPost(id) {
			this.$store
				.dispatch("reject_post", {
					postId: id,
				})
				.then((res) => {})
				.catch((err) => {});
		},
		postBodyParser(str) {
			if (str.includes("/***")) {
				str = str.replace("/***", "");
				return str;
			} else if (str.includes("/*/**")) {
				str = str.replace("/*/**", "");
				return str;
			} else {
				return str;
			}
		},
		postBodySpecial(str) {
			if (str.includes("/***")) {
				return "yellow-border";
			} else if (str.includes("/*/**")) {
				return "red-border";
			} else {
				return "";
			}
		},
	},
};
</script>

<style></style>
