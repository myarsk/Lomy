<template>
    <div class="form-wrap">
        <div class="lomy-logo-wrap">
            <img src="/img/Logo.svg" class="lomy-logo" />
        </div>
        <h1>{{ $vuetify.lang.t("$vuetify.join_community") }}</h1>
        <v-form>
            <div class="buttons">
                <v-btn color="#faf9fd" rounded to="/signin">
                    {{ $vuetify.lang.t("$vuetify.sign_in") }}
                </v-btn>
                <v-btn color="#faf9fd" rounded to="/signup">
                    {{ $vuetify.lang.t("$vuetify.sign_up") }}
                </v-btn>
            </div>
        </v-form>
    </div>
</template>

<script>
export default {
    name: "Welcome",
};
</script>

<style>
</style>