<template>
    <div class="form-wrap">
        <div class="lomy-logo-wrap">
            <img src="/img/Logo.svg" class="lomy-logo" />
        </div>
        <h1>{{ $vuetify.lang.t("$vuetify.verify") }}</h1>
        <p class="red--text">{{error}}</p>
        <v-form @submit.prevent="verify">
            <v-text-field
                v-model="email"
                :error-messages="emailErrors"
                :placeholder="$vuetify.lang.t('$vuetify.email')"
                required
                solo
                @input="$v.email.$touch()"
                @blur="$v.email.$touch()"
            ></v-text-field>
            <v-text-field
                v-model="code"
                :error-messages="codeErrors"
                :placeholder="$vuetify.lang.t('$vuetify.code')"
                required
                solo
                @input="$v.code.$touch()"
                @blur="$v.code.$touch()"
            ></v-text-field>
            <v-btn color="accent" rounded type="submit">{{
                $vuetify.lang.t("$vuetify.submit")
            }}</v-btn>
        </v-form>
    </div>
</template>

<script>
import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
import { mapGetters } from 'vuex';

export default {
    name: "Verify",
    mixins: [validationMixin],
    validations: {
      code: { required },
      email: { required },
    },
    props: ["overlay", "toggleOverlay"],
    data() {
        return {
            code: null,
            email: null,
            error: null
        }
    },
    computed: {
      ...mapGetters(['verifyEmail']),
      codeErrors () {
        const errors = []
        if (!this.$v.code.$dirty) return errors
        !this.$v.code.required && errors.push(this.$vuetify.lang.t('$vuetify.code')+' '+this.$vuetify.lang.t('$vuetify.is_required')+'.')
        return errors
      },
      emailErrors () {
        const errors = []
        if (!this.$v.email.$dirty) return errors
        !this.$v.email.required && errors.push(this.$vuetify.lang.t('$vuetify.email')+' '+this.$vuetify.lang.t('$vuetify.is_required')+'.')
        return errors
      },
    },
    methods: {
        verify() {
            this.toggleOverlay(true);
            this.$v.$touch()
            if (!this.$v.$invalid) {
                this.$store.dispatch(
                    "verify",
                    {
                        activationCode: this.code,
                        email: this.email,
                    }
                    ).then((res) => {
                        this.toggleOverlay(false);
                        this.$router.push("/signin");
                    }).catch((err) => {
                        this.toggleOverlay(false);
                        // this.error = this.$vuetify.lang.t("$vuetify.code")+" "+this.$vuetify.lang.t("$vuetify.might_be_wrong") +"."
                        this.error = err.response.data
                    })
            } else {
                this.toggleOverlay(false);
            }
        },
    },
};
</script>

<style>
</style>