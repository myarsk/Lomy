<template>
    <div class="form-wrap">
        <div class="lomy-logo-wrap">
            <img src="/img/Logo.svg" class="lomy-logo" />
        </div>
        <h1>{{ $vuetify.lang.t("$vuetify.sign_in") }}</h1>
        <v-form @submit.prevent="signin">
            <v-text-field
                solo
                v-model="username"
                :placeholder="$vuetify.lang.t('$vuetify.username')"
                :error-messages="usernameError"
            ></v-text-field>
            <v-text-field
                solo
                type="password"
                v-model="password"
                :placeholder="$vuetify.lang.t('$vuetify.password')"
                :error-messages="passwordError"
            ></v-text-field>
            <router-link to="/signup" class="form-sublink"
                >{{ $vuetify.lang.t("$vuetify.create_new_acc") }}</router-link
            >
            <v-btn color="accent" rounded type="submit">{{ $vuetify.lang.t("$vuetify.submit") }}</v-btn>
        </v-form>
    </div>
</template>

<script>
export default {
    name: "Signin",
    props: ["overlay", "toggleOverlay"],
    data() {
        return {
            username: '',
            password: '',
            usernameError: [],
            passwordError: [],
        }
    },
    methods: {
        signin() {
            this.toggleOverlay(true);
            this.$store.dispatch(
                "login",
                {
                    username: this.username,
                    password: this.password,
                }
                ).then((res) => {
                    this.toggleOverlay(false);
                    this.$route.query.redirect? this.$router.push(this.$route.query.redirect):this.$router.push("/");
                }).catch((err) => {
                    this.toggleOverlay(false);
                    if (
                        err.response.status == 403 &&
                        err.response.data == "please activate this user"
                    ) {
                        this.$router.push("/verify");
                    }
                    this.usernameError = [this.$vuetify.lang.t("$vuetify.username") +" " +this.$vuetify.lang.t("$vuetify.might_be_wrong") +"."];
                    this.passwordError = [this.$vuetify.lang.t("$vuetify.password") +" " +this.$vuetify.lang.t("$vuetify.might_be_wrong") +"."];
                })
        },
    },
};
</script>

<style>
</style>