<template>
    <div class="form-wrap">
        <div class="lomy-logo-wrap">
            <img src="/img/Logo.svg" class="lomy-logo" />
        </div>
        <h1>{{ $vuetify.lang.t("$vuetify.sign_up") }}</h1>
        <v-form @submit.prevent="signup">
            <v-text-field
                v-model="username"
                :error-messages="usernameErrors"
                :placeholder="$vuetify.lang.t('$vuetify.username')"
                required
                solo
                @input="$v.username.$touch()"
                @blur="$v.username.$touch()"
            ></v-text-field>
            <v-text-field
                v-model="email"
                :error-messages="emailErrors"
                :placeholder="$vuetify.lang.t('$vuetify.email')"
                required
                solo
                @input="$v.email.$touch()"
                @blur="$v.email.$touch()"
            ></v-text-field>
            <v-text-field
                type="password"
                v-model="password"
                :error-messages="passwordErrors"
                :placeholder="$vuetify.lang.t('$vuetify.password')"
                required
                solo
                @input="$v.password.$touch()"
                @blur="$v.password.$touch()"
            ></v-text-field>
            <router-link to="/signin" class="form-sublink">{{
                $vuetify.lang.t("$vuetify.already_have_acc")
            }}</router-link>
            <v-btn color="accent" rounded type="submit">{{
                $vuetify.lang.t("$vuetify.submit")
            }}</v-btn>
        </v-form>
    </div>
</template>

<script>
import { validationMixin } from 'vuelidate'
import { required, maxLength, minLength, email } from 'vuelidate/lib/validators'

export default {
    name: "Signup",
    mixins: [validationMixin],
    validations: {
      username: { required, maxLength: maxLength(20), minLength: minLength(5) },
      email: { required, email },
      password: { required, minLength: minLength(8) },
    },
    props: ["overlay", "toggleOverlay"],
    data() {
        return {
            username: null,
            email: null,
            password: null,
        }
    },
    computed: {
      usernameErrors () {
        const errors = []
        if (!this.$v.username.$dirty) return errors
        !this.$v.username.maxLength && errors.push(this.$vuetify.lang.t("$vuetify.username") +" " +this.$vuetify.lang.t("$vuetify.must_be_at_most") +" 20 " +this.$vuetify.lang.t("$vuetify.characters_long") +".")
        !this.$v.username.minLength && errors.push(this.$vuetify.lang.t("$vuetify.username") +" " +this.$vuetify.lang.t("$vuetify.must_be_at_least") +" 5 " +this.$vuetify.lang.t("$vuetify.characters_long") +".")
        !this.$v.username.required && errors.push(this.$vuetify.lang.t('$vuetify.username')+' '+this.$vuetify.lang.t('$vuetify.is_required')+'.')
        return errors
      },
      emailErrors () {
        const errors = []
        if (!this.$v.email.$dirty) return errors
        !this.$v.email.email && errors.push(this.$vuetify.lang.t('$vuetify.must_valid_email'))
        !this.$v.email.required && errors.push(this.$vuetify.lang.t('$vuetify.email')+' '+this.$vuetify.lang.t('$vuetify.is_required')+'.')
        return errors
      },
      passwordErrors () {
        const errors = []
        if (!this.$v.password.$dirty) return errors
        !this.$v.password.minLength && errors.push(this.$vuetify.lang.t("$vuetify.password") +" " +this.$vuetify.lang.t("$vuetify.must_be_at_least") +" 8 " +this.$vuetify.lang.t("$vuetify.characters_long") +".")
        !this.$v.password.required && errors.push(this.$vuetify.lang.t('$vuetify.password')+' '+this.$vuetify.lang.t('$vuetify.is_required')+'.')
        return errors
      },
    },
    methods: {
        signup() {
            this.toggleOverlay(true);
            this.$v.$touch()
            if (!this.$v.$invalid) {
                this.$store.dispatch(
                    "register",
                    {
                        userName: this.username,
                        email: this.email,
                        password: this.password
                    }
                    ).then((res) => {
                        this.toggleOverlay(false);
                        this.$router.push("/signin");
                    }).catch((err) => {
                        this.toggleOverlay(false);
                    })
            } else {
                this.toggleOverlay(false);
            }
        },
    },
};
</script>

<style>
</style>