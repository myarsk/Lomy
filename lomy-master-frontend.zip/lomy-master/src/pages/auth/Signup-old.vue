<template>
    <div class="form-wrap">
        <div class="lomy-logo-wrap">
            <img src="/img/Logo.svg" class="lomy-logo" />
        </div>
        <h1>{{ $vuetify.lang.t("$vuetify.sign_up") }}</h1>
        <v-form @submit.prevent="signup">
            <v-text-field
                solo
                :placeholder="$vuetify.lang.t('$vuetify.email')"
            ></v-text-field>
            <v-text-field
                solo
                type="password"
                :placeholder="$vuetify.lang.t('$vuetify.password')"
            ></v-text-field>
            <router-link to="/signin" class="form-sublink"
                >{{ $vuetify.lang.t("$vuetify.already_have_acc") }}</router-link
            >
            <div class="sign-with">
                <p>{{ $vuetify.lang.t("$vuetify.sign_with") }}</p>
                <hr />
                <a href="#"><img src="/img/facebook.svg" /></a>
                <a href="#"><img src="/img/facebook.svg" /></a>
                <a href="#"><img src="/img/facebook.svg" /></a>
            </div>
            <v-btn color="accent" rounded type="submit">{{
                $vuetify.lang.t("$vuetify.submit")
            }}</v-btn>
        </v-form>
    </div>
</template>

<script>
export default {
    name: "Signup",
    methods: {
        signup() {
            this.$router.push("/signin");
        },
    },
};
</script>

<style>
</style>