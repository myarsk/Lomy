import Vue from "vue";
import Vuetify from "vuetify/lib";
import en from "../locale/en.json";
import ar from "../locale/ar.json";
import { colors } from "vuetify/lib";

Vue.use(Vuetify);

export default new Vuetify({
  lang: {
    locales: { en, ar },
    current: localStorage.getItem("locale")
      ? localStorage.getItem("locale")
      : "en"
  },
  rtl: localStorage.getItem("rtl")
    ? JSON.parse(localStorage.getItem("rtl"))
    : false,
  // direction: localStorage.getItem("rtl")? 'left': 'right',
  // invdirection: localStorage.getItem("rtl")? 'right': 'left',
  theme: {
    dark: localStorage.getItem("dark")
    ? JSON.parse(localStorage.getItem("dark"))
    : false,
    options: {
      customProperties: true
    },
    themes: {
      light: {
        primary: "#14213d",
        secondary: "#373737",
        input: "#ffffff",
        accent: "#ffb300",
        error: "#FF5252",
        info: "#2196F3",
        success: "#4CAF50",
        warning: "#FFC107",
        btn: "#14213d",
        btn_bg: colors.shades.transparent,
        btn_active: "#faf9fd",
        btn_active_bg: "#14213d",
        btn_active_hover: "#faf9fd",
        btn_hover: "#faf9fd",
        btn_hover_bg: "#364159",
        scroll_bg: "#faf9fd" ,
        scroll: "#373737" 
      },
      dark: {
        primary: "#faf9fd",
        secondary: "#373737",
        input: "#1E1E1E",
        hover: "#373737",
        accent: "#ffb300",
        error: "#FF5252",
        info: "#2196F3",
        success: "#4CAF50",
        warning: "#FFC107",
        btn: "#faf9fd",
        btn_bg: colors.shades.transparent,
        btn_active: "#373737",
        btn_active_bg: "#faf9fd",
        btn_active_hover: "#373737",
        btn_hover: "#faf9fd",
        btn_hover_bg: "#373737",
        scroll_bg: "#373737" ,
        scroll: "#ffb300"
      }
    }
  }
});
