<template>
    <div>
        <nav class="navbar-container">
            <router-link to="/">
                <img src="/img/Logo.svg" />
            </router-link>

            <ul class="navbar-wrap">
                <li
                    v-for="item in navigation"
                    :key="item.title"
                    class="navbar-item"
                >
                    <router-link :to="item.link" class="navbar-link">
                        <span>
                            {{ item.title }}
                        </span>
                    </router-link>
                </li>
            </ul>
            <v-tooltip bottom>
                <template v-slot:activator="{ on, attrs }">
                    <v-btn
                        icon
                        v-on="on"
                        v-bind="attrs"
                        to="/policy"
                        :class="$vuetify.rtl ? 'policy policy-left' : 'policy'"
                        >?</v-btn
                    >
                </template>
                <span>{{ $vuetify.lang.t("$vuetify.lomy_polices") }}</span>
            </v-tooltip>
            <div class="site-settings">
                <v-tooltip bottom>
                    <template v-slot:activator="{ on, attrs }">
                        <div v-bind="attrs" v-on="on">
                            <v-switch
                                color="accent"
                                v-model="navTheme"
                                hide-details
                                inset
                            ></v-switch>
                        </div>
                    </template>
                    <span>{{$vuetify.theme.dark? 'Dark':'Light'}}</span>
                </v-tooltip>

                <v-select
                    :items="['en', 'ar']"
                    append-icon="mdi-earth"
                    v-model="$vuetify.lang.current"
                    @change="navLocale($vuetify.lang.current)"
                    solo
                    dense
                ></v-select>
            </div>
            <v-tooltip v-if="role && role != 'ROLE_AUTHOR'" bottom>
                <template v-slot:activator="{ on, attrs }">
                    <v-btn
                        v-on="on"
                        v-bind="attrs"
                        id="settings-btn"
                        color="primary"
                        rounded
                        icon
                        to="/settings"
                        large
                        v-if="role && role != 'ROLE_AUTHOR'"
                    >
                        <v-icon dark> mdi-cog </v-icon>
                    </v-btn>
                </template>
                <span>{{ $vuetify.lang.t("$vuetify.settings") }}</span>
            </v-tooltip>
            <v-tooltip bottom>
                <template v-slot:activator="{ on, attrs }">
                    <v-btn
                        v-on="on"
                        v-bind="attrs"
                        id="logout-btn"
                        color="accent"
                        rounded
                        icon
                        large
                        @click.stop="logout_dialog = true"
                    >
                        <v-icon dark> mdi-logout </v-icon>
                    </v-btn>
                </template>
                <span>{{ $vuetify.lang.t("$vuetify.logout") }}</span>
            </v-tooltip>
        </nav>
        <v-app-bar fixed height="75px" flat class="responsive-navbar">
            <v-app-bar-nav-icon
                @click.stop="drawer = !drawer"
            ></v-app-bar-nav-icon>

            <v-toolbar-title
                ><router-link to="/"> <img src="/img/Logo.svg" /> </router-link
            ></v-toolbar-title>
            <v-spacer></v-spacer>
            <v-tooltip bottom>
                <template v-slot:activator="{ on, attrs }">
                    <div v-bind="attrs" v-on="on">
                        <v-switch
                            color="accent"
                            v-model="navTheme"
                            hide-details
                            inset
                        ></v-switch>
                    </div>
                </template>
                <span>Dark</span>
            </v-tooltip>
            <v-tooltip bottom>
                <template v-slot:activator="{ on, attrs }">
                    <v-btn
                        v-on="on"
                        v-bind="attrs"
                        id="logout-btn"
                        color="accent"
                        rounded
                        icon
                        large
                        @click.stop="logout_dialog = true"
                    >
                        <v-icon dark> mdi-logout </v-icon>
                    </v-btn>
                </template>
                <span>{{ $vuetify.lang.t("$vuetify.logout") }}</span>
            </v-tooltip>
        </v-app-bar>
        <v-navigation-drawer
            v-model="drawer"
            :right="$vuetify.rtl"
            fixed
            temporary
        >
            <v-btn :right="!$vuetify.rtl" @click="drawer = false" icon>
                <v-icon>mdi-close</v-icon>
            </v-btn>
            <router-link class="lomy-logo" to="/">
                <img src="/img/Logo.svg" />
            </router-link>
            <v-list dense>
                <v-list-item
                    v-for="item in navigation"
                    :key="item.title"
                    :to="item.link"
                >
                    <v-list-item-content>
                        <v-list-item-title>{{ item.title }}</v-list-item-title>
                    </v-list-item-content>
                </v-list-item>
            </v-list>
            <v-select
                :items="['en', 'ar']"
                append-icon="mdi-earth"
                v-model="$vuetify.lang.current"
                @change="navLocale($vuetify.lang.current)"
                solo
                dense
            ></v-select>
            <v-btn
                id="settings-btn"
                :class="$vuetify.rtl ? 'settings-left' : ''"
                color="primary"
                rounded
                icon
                to="/settings"
            >
                <v-icon dark> mdi-cog </v-icon>
            </v-btn>
            <router-link
                to="/policy"
                :class="$vuetify.rtl ? 'policy policy-left' : 'policy'"
                >?</router-link
            >
        </v-navigation-drawer>
        <v-dialog v-model="logout_dialog" max-width="290">
            <v-card>
                <v-card-title class="headline">
                    {{ $vuetify.lang.t("$vuetify.confirm_logout") }}
                </v-card-title>

                <v-card-actions>
                    <v-spacer></v-spacer>

                    <v-btn color="secondary" @click="logout_dialog = false">
                        {{ $vuetify.lang.t("$vuetify.cancel") }}
                    </v-btn>

                    <v-btn color="accent" @click.stop="logout">
                        {{ $vuetify.lang.t("$vuetify.logout") }}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>

<script>
import { mapGetters } from 'vuex';
export default {
    name: "Navbar",
    props: ["navigation", "changeLocale", "changeTheme"],
    data() {
        return {
            // navLocale: this.locale,
            navTheme: this.$vuetify.theme.dark,
            drawer: null,
            logout_dialog: false,
        };
    },
    computed: {
        ...mapGetters(["role"])
    },
    watch: {
        navTheme: function (val) {
            this.changeTheme(val);
        },
    },
    methods: {
        logout() {
            this.$store.dispatch("logout"
            ).then(()=> {
                this.$router.push("/welcome");
            })
        },
        navLocale: function (val) {
            this.changeLocale(val);
        },
    },
};
</script>
