<template>
    <v-footer
        :class="
            $vuetify.rtl
                ? 'footer-container footer-container-rtl'
                : 'footer-container'
        "
    >
        <v-row>
            <v-col cols="12" md="6" class="left-footer-section">
                <div class="footer-logo">
                    <img src="/img/Logo.svg" alt="" />
                </div>
                <p>
                    {{ $vuetify.lang.t("$vuetify.footer_desc") }}
                </p>
            </v-col>
            <v-col cols="12" md="6">
                <div class="follow-us">
                    <div class="yellow-circle"></div>
                    {{ $vuetify.lang.t("$vuetify.follow_us") }}
                    <div class="media">
                        <a href="#"><img src="/img/facebook.svg" alt="" /></a>
                        <a href="#"
                            ><img src="/img/instagram-sketched.svg" alt=""
                        /></a>
                        <a href="#"><img src="/img/twitter.svg" alt="" /></a>
                    </div>
                </div>
            </v-col>

            <img src="/img/caret footer.svg" class="caret-footer" alt="" />
            <!-- <button
                @click="
                    $vuetify.goTo(0, {
                        duration: 100,
                        offset: 0,
                        easing: 'easeOutCubic',
                    })
                "
                class="up-btn"
            >
                <img src="/img/UP.svg" alt="" />
            </button> -->
            <a href="#" @click="$vuetify.goTo(0)" class="up-btn">
                <img src="/img/UP.svg" alt="" />
            </a>
        </v-row>
    </v-footer>
</template>

<script>
export default {
    name: "Footer",
};
</script>

<style>
</style>