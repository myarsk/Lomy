<template>
    <v-container class="auth-container" fluid>
        <div class="site-settings">
            <v-switch
                color="accent"
                v-model="authTheme"
                hide-details
                inset
            ></v-switch>
            <v-select
                :items="['en', 'ar']"
                append-icon="mdi-earth"
                v-model="$vuetify.lang.current"
                @change="authLocale($vuetify.lang.current)"
                solo
                dense
            ></v-select>
        </div>
        <v-row no-gutters>
            <v-col class="img-container" :data-aos="$vuetify.rtl? 'fade-left': 'fade-right'" cols="3" md="5">
                <img src="/img/Humaaan.svg" />
            </v-col>
            <v-col class="form-container" cols="9" md="7">
                <slot></slot>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
export default {
    name: "Auth",
    props: ["changeLocale", "changeTheme"],
    data() {
        return {
            authTheme: this.$vuetify.theme.dark,
        };
    },
    watch: {
        authTheme: function (val) {
            this.changeTheme(val);
        },
    },
    methods: {
        authLocale: function (val) {
            this.changeLocale(val);
        },
    }
};
</script>

<style>
</style>