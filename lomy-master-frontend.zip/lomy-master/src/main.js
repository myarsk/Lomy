import Vue from "vue";
import './plugins/axios'
import App from "./App.vue";
import VueRouter from "vue-router";
import Vuex from "vuex";
import vuetify from "./plugins/vuetify";
import "./registerServiceWorker";
import router from "./router.js";
import store from "./store/index.js";
import AOS from 'aos';
import 'aos/dist/aos.css';
import "./assets/main.scss";
import ScrollLoader from 'vue-scroll-loader';
import Meta from 'vue-meta';
import VueSocialSharing from 'vue-social-sharing'

var abbreviate = require('number-abbreviate')

Vue.filter("formatNumber", function (value) {
return abbreviate(value)
});

Vue.prototype.$formatDecimal = (num, decimals) => num.toLocaleString('en-US', {
  minimumFractionDigits: 2,      
  maximumFractionDigits: 2,
});


Vue.use(Meta);
Vue.use(ScrollLoader);
Vue.use(VueRouter);
Vue.use(Vuex);
Vue.use(VueSocialSharing);

Vue.config.productionTip = false;

new Vue({
  created() {
    AOS.init({ duration: 700 })
  },
  vuetify,
  router,
  store,
  render: h => h(App)
}).$mount("#app");
