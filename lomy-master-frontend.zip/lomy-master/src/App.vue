<template>
    <v-app>
        <transition
            name="fade"
            mode="out-in"
            @beforeLeave="beforeLeave"
            @enter="enter"
            @afterEnter="afterEnter"
        >
            <Navbar
                :changeTheme="changeTheme"
                :changeLocale="changeLocale"
                :navigation="navigation"
                v-if="$route.meta.auth"
            ></Navbar>
        </transition>
        <v-main :class="$route.meta.auth ? 'mt-md-75' : ''">
            <transition
                name="fade"
                mode="out-in"
                @beforeLeave="beforeLeave"
                @enter="enter"
                @afterEnter="afterEnter"
            >
                <Auth
                    v-if="!$route.meta.auth"
                    :changeLocale="changeLocale"
                    :changeTheme="changeTheme"
                >
                    <transition
                        name="fade"
                        mode="out-in"
                        @beforeLeave="beforeLeave"
                        @enter="enter"
                        @afterEnter="afterEnter"
                    >
                        <router-view :toggleOverlay="toggleOverlay" :overlay="overlay"></router-view>
                    </transition>
                </Auth>
                <router-view v-else :toggleOverlay="toggleOverlay" :overlay="overlay"></router-view>
            </transition>
            <v-overlay :value="overlay">
                <v-progress-circular
                    color="accent"
                    indeterminate
                    size="64"
                ></v-progress-circular>
            </v-overlay>
        </v-main>
        <transition
            name="fade"
            mode="out-in"
            @beforeLeave="beforeLeave"
            @enter="enter"
            @afterEnter="afterEnter"
        >
            <Footer
                v-if="$route.path != '/contact' && $route.meta.auth"
            ></Footer>
        </transition>
    </v-app>
</template>

<script>
import Navbar from "./components/Navbar.vue";
import Footer from "./components/Footer.vue";
import Auth from "./components/Auth.vue";
export default {
    name: "App",
    metaInfo: {
        // Children can override the title.
        title: 'Lomy',
        // Result: My Page Title ← My Site
        // If a child changes the title to "My Other Page Title",
        // it will become: My Other Page Title ← My Site
        titleTemplate: '%s',
        // Define meta tags here.
        meta: [
            {"http-equiv": 'Content-Type', content: 'text/html; charset=utf-8'},
            {name: 'viewport', content: 'width=device-width, initial-scale=1'},
            {name: 'description', content: 'The best safety way to express.'},
            {name: 'author', content: 'Yazan Al Olabi https://www.linkedin.com/in/yazan-olabi-755111190/'},
            {name: 'og:title', property: "og:title", content: 'Lomy'},
            {name: 'og:description', property: "og:description", content: 'The best safety way to express.'},
            {name: 'og:image', property: "og:image", content: '/favicon.svg'},
        ]
    },
    data: () => ({
        overlay: false,
        prevHeight: 0,
    }),
    components: {
        Navbar,
        Footer,
        Auth,
    },
    methods: {
        changeLocale(val) {
            if (val == "ar") {
                this.$vuetify.lang.current = "ar";
                this.$vuetify.rtl = true;
                // this.$vuetify.direction = 'left';
                // this.$vuetify.invdirection = 'right';
                localStorage.setItem("locale", "ar");
                localStorage.setItem("rtl", true);
            } else {
                this.$vuetify.lang.current = val;
                this.$vuetify.rtl = false;
                // this.$vuetify.direction = 'right';
                // this.$vuetify.invdirection = 'left';
                localStorage.setItem("locale", val);
                localStorage.setItem("rtl", false);
            }
        },
        changeTheme(val) {
            localStorage.setItem("dark", val);
            this.$vuetify.theme.dark = val;
        },
        toggleOverlay(val) {
            this.overlay = val;
        },
        beforeLeave(element) {
            this.prevHeight = getComputedStyle(element).height;
        },
        enter(element) {
            const { height } = getComputedStyle(element);

            element.style.height = this.prevHeight;
            setTimeout(() => {
                element.style.height = height;
            });
        },
        afterEnter(element) {
            element.style.height = "auto";
        },
    },
    computed: {
        navigation() {
            return [
                { title: this.$vuetify.lang.t("$vuetify.home"), link: "/" },
                {
                    title: this.$vuetify.lang.t("$vuetify.about"),
                    link: "/about",
                },
                {
                    title: this.$vuetify.lang.t("$vuetify.contact"),
                    link: "/contact",
                },
            ];
        },
    },
};
</script>