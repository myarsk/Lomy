// import compression-webpack-plugin
// const CompressionWebpackPlugin = require('compression-webpack-plugin')
 // define compressed file types
// const productionGzipExtensions = ['js', 'html', 'css']
// Image minimzer
// const ImageMinimizerPlugin = require('image-minimizer-webpack-plugin');

module.exports = {
  transpileDependencies: ["vuetify"],
  // configureWebpack: {
  //   plugins: [
  //     new webpack.IgnorePlugin(/^\.\/locale$/, /moment$/)
  //   ]
  // },
  // devServer: {
  //   open: process.platform === 'darwin',
  //   host: '0.0.0.0',
  //   port: 8080, // CHANGE YOUR PORT HERE!
  //   https: true,
  //   hotOnly: false,
  // },
  configureWebpack: {
    plugins: [
      // new CompressionWebpackPlugin({
      //   filename: '[path].gz[query]',
      //   algorithm: 'gzip',
      //   test: new RegExp('\\.(' + productionGzipExtensions.join('|') + ')$'),
      //   threshold: 10240,
      //   minRatio: 0.8,
      // }),
      // new ImageMinimizerPlugin({
      //   minimizerOptions: {
      //     // Lossless optimization with custom option
      //     // Feel free to experiment with options for better result for you
      //   test: /\.(jpe?g|png|gif|svg)$/i,
      //   loader: 'file-loader', // Or `url-loader` or your other loader
      //   severityError: 'warning', // Ignore errors on corrupted images
      //     plugins: [
      //       ['gifsicle', { interlaced: true }],
      //       ['jpegtran', { progressive: true }],
      //       ['optipng', { optimizationLevel: 5 }],
      //       // [
      //       //   'svgo',
      //       //   {
      //       //     plugins: [
      //       //       {
      //       //         removeViewBox: false,
      //       //       },
      //       //     ],
      //       //   },
      //       // ],
      //     ],
      //   },
      // }),
    ]
  },
  chainWebpack(config) {
    config.plugins.delete('prefetch');
  },
  pwa: {
    name: 'Lomy',
    themeColor: '#ffb300',
    backgroundColor: '#ffb300',
    msTileColor: '#ffb300',
    appleMobileWebAppCapable: 'yes',
    appleMobileWebAppStatusBarStyle: '#14213d',
    iconPaths: {
      favicon32: 'img/icons/favicon-32x32.png',
      favicon16: 'img/icons/favicon-16x16.png',
      appleTouchIcon: 'img/icons/apple-touch-icon.png',
      maskIcon: 'img/icons/safari-pinned-tab.svg',
      msTileImage: 'img/icons/mstile-144x144.png'
    }
  }
};
